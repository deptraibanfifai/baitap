package com.library;

import com.library.NetSend;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.net.MulticastSocket;
import java.net.NetworkInterface;
import java.net.Inet4Address;
import java.util.Collections;


/** Giao diện Swing; tác vụ mạng chạy nền để cửa sổ luôn phản hồi. */
public class NetSendApp extends JFrame {
    private final JTextField group = new JTextField("239.255.10.10", 16);
    private final JTextField target = new JTextField("127.0.0.1", 16);
    private final JComboBox<String> mode = new JComboBox<>(new String[]{"Một máy (IP)", "Nhóm multicast", "Tất cả máy"});
    private final JTextArea message = new JTextArea(3, 30);
    private final JTextArea history = new JTextArea();
    private final JTextField command = new JTextField();
    private final JLabel status = new JLabel("Chưa bắt đầu nhận");
    private final JButton listen = new JButton("Bắt đầu nhận");
    private final JButton send = new JButton("Gửi tin nhắn");
    private final JButton execute = new JButton("Thực hiện lệnh");
    private final JComboBox<String> adapter = new JComboBox<>();
    private final JLabel ipLabel = new JLabel("Chọn card mạng để gửi và nhận");
    private boolean busy;
    private volatile MulticastSocket receiver;
    private volatile boolean closed;

    public NetSendApp() {
        super("Net Send • UDP / Multicast");
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        Color background = new Color(242, 246, 252);
        JPanel root = new JPanel(new BorderLayout(18, 18));
        root.setBackground(background);
        root.setBorder(new EmptyBorder(22, 22, 22, 22));
        setContentPane(root);

        JPanel heading = new JPanel(new BorderLayout(8, 4));
        heading.setOpaque(false);
        JLabel title = new JLabel("Net Send");
        title.setFont(new Font("SansSerif", Font.BOLD, 30));
        title.setForeground(new Color(28, 57, 105));
        JLabel subtitle = new JLabel("Gửi tin nhắn đến một máy, một nhóm hoặc toàn mạng");
        subtitle.setForeground(new Color(96, 112, 136));
        heading.add(title, BorderLayout.NORTH);
        heading.add(subtitle, BorderLayout.CENTER);
        root.add(heading, BorderLayout.NORTH);

        JPanel content = new JPanel(new BorderLayout(16, 16));
        content.setOpaque(false);
        JPanel settings = card("Kết nối mạng");
        settings.setPreferredSize(new Dimension(290, 420));
        settings.setLayout(new BoxLayout(settings, BoxLayout.Y_AXIS));
        settings.add(label("Card mạng"));
        adapter.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        settings.add(adapter);
        settings.add(Box.createVerticalStrut(10));
        ipLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        settings.add(ipLabel);
        settings.add(Box.createVerticalStrut(24));
        settings.add(label("Nhóm multicast đang nhận"));
        group.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
        group.setAlignmentX(Component.LEFT_ALIGNMENT);
        settings.add(group);
        settings.add(Box.createVerticalStrut(12));
        listen.setAlignmentX(Component.LEFT_ALIGNMENT);
        settings.add(listen);
        settings.add(Box.createVerticalStrut(14));
        status.setAlignmentX(Component.LEFT_ALIGNMENT);
        status.setForeground(new Color(34, 128, 94));
        settings.add(status);
        settings.add(Box.createVerticalGlue());
        JLabel help = new JLabel("<html><b>Thử trên một máy</b><br>Gửi đến 127.0.0.1.<br><br><b>Thử giữa các máy</b><br>Mở chương trình trên máy nhận.<br>Chọn card Wi-Fi / Ethernet cùng LAN.<br>Cho phép UDP cổng 5000.</html>");
        help.setForeground(new Color(96, 112, 136));
        help.setAlignmentX(Component.LEFT_ALIGNMENT);
        settings.add(help);
        content.add(settings, BorderLayout.WEST);

        JPanel right = new JPanel(new BorderLayout(14, 14));
        right.setOpaque(false);
        JPanel log = card("Tin nhắn và hoạt động");
        log.setLayout(new BorderLayout(8, 8));
        history.setEditable(false);
        history.setLineWrap(true); history.setWrapStyleWord(true);
        history.setFont(new Font("SansSerif", Font.PLAIN, 14));
        history.setMargin(new Insets(12, 12, 12, 12));
        history.setForeground(new Color(38, 53, 76));
        JScrollPane logScroll = new JScrollPane(history);
        logScroll.setBorder(BorderFactory.createEmptyBorder());
        log.add(logScroll, BorderLayout.CENTER);
        JButton clear = new JButton("Xóa lịch sử");
        clear.addActionListener(e -> history.setText(""));
        JPanel logActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        logActions.setOpaque(false); logActions.add(clear);
        log.add(logActions, BorderLayout.SOUTH);
        right.add(log, BorderLayout.CENTER);

        JPanel compose = card("Soạn tin nhắn");
        compose.setLayout(new BorderLayout(10, 10));
        JPanel destination = new JPanel(new BorderLayout(10, 0));
        destination.setOpaque(false);
        mode.setPreferredSize(new Dimension(190, 38));
        destination.add(mode, BorderLayout.WEST);
        destination.add(target, BorderLayout.CENTER);
        compose.add(destination, BorderLayout.NORTH);
        message.setRows(4); message.setLineWrap(true); message.setWrapStyleWord(true);
        message.setMargin(new Insets(10, 10, 10, 10));
        compose.add(new JScrollPane(message), BorderLayout.CENTER);
        JPanel sendRow = new JPanel(new BorderLayout(10, 0));
        sendRow.setOpaque(false);
        JLabel hint = new JLabel("UDP · Nội dung tối đa 4096 byte");
        hint.setForeground(new Color(96, 112, 136));
        sendRow.add(hint, BorderLayout.CENTER); sendRow.add(send, BorderLayout.EAST);
        compose.add(sendRow, BorderLayout.SOUTH);
        right.add(compose, BorderLayout.SOUTH);
        content.add(right, BorderLayout.CENTER);
        root.add(content, BorderLayout.CENTER);

        JPanel commands = card("Lệnh nhanh — mỗi lần nhập một lệnh");
        commands.setLayout(new BorderLayout(10, 8));
        JLabel example = new JLabel("Ví dụ: net send group Xin chào nhóm");
        example.setForeground(new Color(96, 112, 136));
        commands.add(example, BorderLayout.NORTH);
        command.setPreferredSize(new Dimension(350, 38));
        commands.add(command, BorderLayout.CENTER); commands.add(execute, BorderLayout.EAST);
        root.add(commands, BorderLayout.SOUTH);
        for (JButton button : new JButton[]{listen, send, execute}) {
            button.setBackground(new Color(43, 103, 215));
            button.setForeground(Color.WHITE);
            button.setFocusPainted(false);
            button.setBorder(new EmptyBorder(10, 16, 10, 16));
        }
        group.setAlignmentX(Component.LEFT_ALIGNMENT);
        adapter.setAlignmentX(Component.LEFT_ALIGNMENT);
        mode.addActionListener(e -> updateTarget());
        listen.addActionListener(e -> {
            if (!busy) { if (receiver != null) stopReceiving(); else startReceiving(); }
        });
        send.addActionListener(e -> dispatch(target.getText().trim(), message.getText()));
        execute.addActionListener(e -> runCommand());
        command.addActionListener(e -> runCommand());
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosed(WindowEvent e) { closed = true; stopReceiving(); }
        });
        setSize(1060, 800); setMinimumSize(new Dimension(950, 720)); setLocationRelativeTo(null);
        adapter.addActionListener(e -> selectAdapter());
        new SwingWorker<java.util.List<String>, Void>() {
            protected java.util.List<String> doInBackground() throws Exception {
                java.util.List<String> result = new java.util.ArrayList<>();
                for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (java.net.InetAddress address : Collections.list(ni.getInetAddresses())) {
                        if (address instanceof Inet4Address)
                            result.add(ni.getName() + " | " + address.getHostAddress());
                    }
                }
                return result;
            }
            protected void done() {
                try {
                    for (String value : get()) adapter.addItem(value);
                    if (adapter.getItemCount() == 0) {
                        ipLabel.setText("Không có card mạng IPv4");
                        append("Chưa tìm thấy card mạng đang hoạt động.");
                    }
                } catch (Exception e) { append("Lỗi đọc card mạng: " + error(e)); }
            }
        }.execute();
    }

    private static JPanel card(String title) {
        JPanel panel = new JPanel();
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(220, 229, 241)),
            BorderFactory.createCompoundBorder(
                BorderFactory.createTitledBorder(BorderFactory.createEmptyBorder(), title,
                    javax.swing.border.TitledBorder.LEFT, javax.swing.border.TitledBorder.TOP,
                    new Font("SansSerif", Font.BOLD, 15), new Color(28, 57, 105)),
                new EmptyBorder(12, 14, 14, 14))));
        return panel;
    }

    private static JLabel label(String value) {
        JLabel label = new JLabel(value);
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        label.setBorder(new EmptyBorder(0, 0, 8, 0));
        label.setForeground(new Color(65, 80, 104));
        return label;
    }

    private void selectAdapter() {
        String selected = (String) adapter.getSelectedItem();
        if (selected == null) return;
        NetSend.selectInterface(selected.split(" \\| ")[0]);
        ipLabel.setText("IP máy: " + selected.substring(selected.indexOf('|') + 1).trim());
    }

    private void updateTarget() {
        int selected = mode.getSelectedIndex();
        target.setEnabled(selected != 2);
        target.setText(selected == 0 ? "127.0.0.1" : selected == 1 ? group.getText().trim() : "all");
    }

    private void append(String text) {
        SwingUtilities.invokeLater(() -> {
            if (closed) return;
            history.append(text + "\n"); history.setCaretPosition(history.getDocument().getLength());
        });
    }

    private static String error(Exception e) {
        Throwable cause = e.getCause() != null ? e.getCause() : e;
        return cause.getMessage() == null ? cause.toString() : cause.getMessage();
    }

    private void startReceiving() {
        if (adapter.getSelectedItem() == null) {
            append("Hãy chọn card mạng trước khi bắt đầu nhận."); return;
        }
        String selectedGroup = group.getText().trim();
        busy = true; adapter.setEnabled(false);
        listen.setEnabled(false); group.setEnabled(false); status.setText("Đang tham gia nhóm…");
        new SwingWorker<MulticastSocket, Void>() {
            protected MulticastSocket doInBackground() throws Exception { return NetSend.openReceiver(selectedGroup); }
            protected void done() {
                try {
                    MulticastSocket socket = get();
                    if (closed) { socket.close(); return; }
                    receiver = socket;
                    status.setText("Đang nhận · UDP 5000");
                    listen.setText("Dừng nhận");
                    append("Đã tham gia nhóm " + selectedGroup + ". Sẵn sàng nhận tin riêng, nhóm và toàn mạng.");
                    Thread thread = new Thread(() -> NetSend.receive(socket, NetSendApp.this::append), "gui-receiver");
                    thread.setDaemon(true); thread.start();
                } catch (Exception e) {
                    status.setText("Không thể bắt đầu nhận"); group.setEnabled(true);
                    append("Lỗi nhận: " + error(e));
                } finally { busy = false; listen.setEnabled(true); if (receiver == null) adapter.setEnabled(true); }
            }
        }.execute();
    }

    private void stopReceiving() {
        MulticastSocket socket = receiver; receiver = null;
        if (socket != null) socket.close();
        listen.setText("Bắt đầu nhận"); group.setEnabled(true); adapter.setEnabled(true); status.setText("Đã dừng nhận");
    }

    private void runCommand() {
        String text = command.getText().trim();
        if (java.util.regex.Pattern.compile("(?i)\\bnet\\s+send\\b").matcher(text).results().count() > 1) {
            JOptionPane.showMessageDialog(this, "Mỗi lần chỉ nhập một lệnh net send. Hãy gửi từng lệnh riêng.", "Có nhiều lệnh trên một dòng", JOptionPane.WARNING_MESSAGE);
            return;
        }
        String[] parts = text.split("\\s+", 4);
        if (parts.length != 4 || !parts[0].equalsIgnoreCase("net") || !parts[1].equalsIgnoreCase("send")) {
            JOptionPane.showMessageDialog(this, "Cú pháp: net send IP|group|all message", "Lệnh chưa đúng", JOptionPane.WARNING_MESSAGE);
            return;
        }
        dispatch(parts[2], parts[3]);
    }

    private void dispatch(String destination, String content) {
        // Từ khóa group trong GUI dùng nhóm đang được chọn trên cửa sổ.
        if (!send.isEnabled()) return;
        String resolved = destination.equalsIgnoreCase("group") ? group.getText().trim() : destination;
        send.setEnabled(false); execute.setEnabled(false); command.setEnabled(false);
        new SwingWorker<Void, Void>() {
            protected Void doInBackground() throws Exception { NetSend.send(new String[]{resolved, content}); return null; }
            protected void done() {
                send.setEnabled(true); execute.setEnabled(true); command.setEnabled(true);
                try { get(); append("Đã gửi UDP đến " + resolved + ": " + content); }
                catch (Exception e) {
                    append("Gửi thất bại: " + error(e));
                    if (!closed) JOptionPane.showMessageDialog(NetSendApp.this, error(e), "Lỗi gửi", JOptionPane.ERROR_MESSAGE);
                }
            }
        }.execute();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
                for (Object key : Collections.list(UIManager.getDefaults().keys()))
                    if (UIManager.get(key) instanceof javax.swing.plaf.FontUIResource)
                        UIManager.put(key, new javax.swing.plaf.FontUIResource("SansSerif", Font.PLAIN, 14));
            }
            catch (Exception ignored) { }
            new NetSendApp().setVisible(true);
        });
    }
}


