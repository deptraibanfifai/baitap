package com.library;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

/**
 * Net send đơn giản: unicast, multicast và broadcast qua UDP.
 */
class NetSend {
    private static final int PORT = 5000;
    private static final int MAX_BYTES = 4096;
    private static final String DEFAULT_GROUP = "239.255.10.10";
    private static volatile String selectedInterface;

    static void selectInterface(String name) {
        selectedInterface = name;
    }

    public static void main(String[] args) {
        try {
            if (args.length > 0 && args[0].equalsIgnoreCase("send")) {
                send(Arrays.copyOfRange(args, 1, args.length));
                return;
            }
            if (args.length > 0 && !args[0].equalsIgnoreCase("receive")) {
                System.out.println("Dùng: java NetSend [receive [groupIP]] hoặc java NetSend send IP|group|all message");
                return;
            }
            String group = args.length > 1 ? args[1] : DEFAULT_GROUP;
            try (MulticastSocket socket = openReceiver(group)) {
                System.out.println("Đang nhận UDP tại cổng " + PORT + ", nhóm " + group);
                System.out.println("IP máy nhận: " + interfaceIPs());
                if (args.length > 0) {
                    receive(socket);
                } else {
                    Thread receiver = new Thread(() -> receive(socket), "receiver");
                    receiver.setDaemon(true);
                    receiver.start();
                    System.out.println("Nhập: net send IP|group|all message. Nhập exit để thoát.");
                    BufferedReader input = new BufferedReader(new InputStreamReader(System.in, StandardCharsets.UTF_8));
                    String line;
                    while ((line = input.readLine()) != null) {
                        if (line.trim().equalsIgnoreCase("exit")) break;
                        String[] parts = line.trim().split("\\s+", 4);
                        if (parts.length != 4 || !parts[0].equalsIgnoreCase("net") || !parts[1].equalsIgnoreCase("send")) {
                            System.out.println("Cú pháp: net send IP|group|all message");
                            continue;
                        }
                        try {
                            send(new String[]{parts[2], parts[3]});
                        } catch (Exception e) {
                            System.err.println("Gửi thất bại: " + e.getMessage());
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Lỗi: " + e.getMessage());
            System.exit(1);
        }
    }

    private static List<NetworkInterface> interfaces() throws SocketException {
        List<NetworkInterface> result = new ArrayList<>();
        String selected = selectedInterface != null ? selectedInterface : System.getenv("NETSEND_INTERFACE");
        for (NetworkInterface ni : Collections.list(NetworkInterface.getNetworkInterfaces())) {
            if (!ni.isUp() || ni.isLoopback()) continue;
            if (selected != null && !selected.isEmpty() && !ni.getName().equals(selected)) continue;
            boolean ipv4 = Collections.list(ni.getInetAddresses()).stream().anyMatch(a -> a instanceof Inet4Address);
            if (ipv4) result.add(ni);
        }
        if (selected != null && !selected.isEmpty() && result.isEmpty())
            throw new SocketException("Không tìm thấy card mạng IPv4 đang hoạt động: " + selected);
        return result;
    }

    static String interfaceIPs() throws SocketException {
        List<String> ips = new ArrayList<>();
        for (NetworkInterface ni : interfaces())
            for (InetAddress a : Collections.list(ni.getInetAddresses()))
                if (a instanceof Inet4Address) ips.add(ni.getName() + "=" + a.getHostAddress());
        return String.join(", ", ips);
    }

    private static InetAddress ipv4(String text) throws Exception {
        if (!text.matches("\\d{1,3}(\\.\\d{1,3}){3}"))
            throw new IllegalArgumentException("Địa chỉ IPv4 không hợp lệ: " + text);
        for (String part : text.split("\\."))
            if (Integer.parseInt(part) > 255) throw new IllegalArgumentException("Địa chỉ IPv4 không hợp lệ: " + text);
        return InetAddress.getByName(text);
    }

    static MulticastSocket openReceiver(String groupText) throws Exception {
        InetAddress group = ipv4(groupText);
        if (!group.isMulticastAddress())
            throw new IllegalArgumentException("Nhóm phải là IP multicast (224.x.x.x đến 239.x.x.x)");
        MulticastSocket socket = new MulticastSocket(null);
        try {
            socket.setReuseAddress(true);
            socket.bind(new InetSocketAddress(PORT));
            socket.setBroadcast(true);
            int joined = 0;
            for (NetworkInterface ni : interfaces()) {
                if (!ni.supportsMulticast()) continue;
                socket.joinGroup(new InetSocketAddress(group, PORT), ni);
                joined++;
            }
            if (joined == 0) throw new SocketException("Không có card mạng hỗ trợ multicast đang hoạt động");
            return socket;
        } catch (Exception e) {
            socket.close();
            throw e;
        }
    }

    private static void receive(MulticastSocket socket) {
        receive(socket, System.out::println);
    }

    static void receive(MulticastSocket socket, java.util.function.Consumer<String> output) {
        byte[] buffer = new byte[MAX_BYTES];
        while (!socket.isClosed()) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            try {
                socket.receive(packet);
                String message = new String(packet.getData(), packet.getOffset(), packet.getLength(), StandardCharsets.UTF_8);
                String time = LocalTime.now().format(DateTimeFormatter.ofPattern("HH:mm:ss"));
                output.accept("[" + time + "] IP gửi: " + packet.getAddress().getHostAddress() + " | Tin nhắn: " + message);
            } catch (Exception e) {
                if (!socket.isClosed()) output.accept("Lỗi nhận: " + e.getMessage());
                break;
            }
        }
    }

    static void send(String[] args) throws Exception {
        if (args.length < 2) throw new IllegalArgumentException("Dùng: net send IP|group|all message");
        String target = args[0];
        String message = String.join(" ", Arrays.copyOfRange(args, 1, args.length));
        byte[] data = message.getBytes(StandardCharsets.UTF_8);
        if (message.trim().isEmpty() || data.length > MAX_BYTES)
            throw new IllegalArgumentException("Tin nhắn phải có nội dung và không vượt quá " + MAX_BYTES + " byte UTF-8");
        try (MulticastSocket socket = new MulticastSocket()) {
            socket.setBroadcast(true);
            socket.setTimeToLive(1); // Giới hạn multicast trong mạng cục bộ.
            if (target.equalsIgnoreCase("all") || target.equals("*")) {
                Set<InetAddress> destinations = new LinkedHashSet<>();
                for (NetworkInterface ni : interfaces())
                    for (InterfaceAddress a : ni.getInterfaceAddresses())
                        if (a.getBroadcast() != null) destinations.add(a.getBroadcast());
                if (destinations.isEmpty()) throw new SocketException("Không tìm thấy địa chỉ broadcast của mạng IPv4");
                for (InetAddress address : destinations)
                    socket.send(new DatagramPacket(data, data.length, address, PORT));
            } else {
                InetAddress address = ipv4(target.equalsIgnoreCase("group") ? DEFAULT_GROUP : target);
                if (address.isMulticastAddress()) {
                    NetworkInterface ni = interfaces().stream().filter(n -> {
                        try {
                            return n.supportsMulticast();
                        } catch (SocketException e) {
                            return false;
                        }
                    }).findFirst().orElseThrow(() -> new SocketException("Không có card mạng hỗ trợ multicast"));
                    socket.setNetworkInterface(ni);
                }
                socket.send(new DatagramPacket(data, data.length, address, PORT));
            }
        }
        System.out.println("Đã gửi UDP đến " + target + ": " + message);
    }
}
