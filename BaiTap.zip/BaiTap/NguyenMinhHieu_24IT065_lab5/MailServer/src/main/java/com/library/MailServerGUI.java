package com.library;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import javax.swing.text.BadLocationException;
import javax.swing.text.Style;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Stream;

/**
 * MailServer GUI - Control panel cho Mail Server UDP (giao thuc MAIL/1.0),
 * thiet ke giao dien dong bo voi MailClientGUI (chu de toi, bo goc tron).
 *
 * Cac chuc nang GUI:
 *   - START / STOP server (chon cong truoc khi start)
 *   - Bang liệt kê toàn bo account da dang ky (so luong thu, dung luong)
 *   - Bang session hien tai (ai dang dang nhap tu dia chi IP nao / luc nao)
 *   - Log theo thoi gian (mau sac phan biet request / response / loi)
 *   - Thong ke tong account, dang online, tong thu da gui, tong byte goi tin
 *   - Wire strip giong client hien thi goi tin vua trao doi
 */
public class MailServerGUI extends JFrame {

    // ------------------------------------------------------------ bang mau + font

    static final Color BG       = new Color(0xF4F6FB);
    static final Color PANEL    = new Color(0xFFFFFF);
    static final Color PANEL_2  = new Color(0xEEF1F8);
    static final Color BORDER   = new Color(0xD4DAE6);
    static final Color TEXT     = new Color(0x1A1F2E);
    static final Color MUTED    = new Color(0x6B7388);
    static final Color ACCENT   = new Color(0x4C8DFF);
    static final Color ACCENT_H = new Color(0x3B7AEE);
    static final Color GREEN    = new Color(0x26A674);
    static final Color RED      = new Color(0xE25050);
    static final Color AMBER    = new Color(0xC58A00);

    static final String FAMILY = "Segoe UI";
    static Font font(int style, int size) { return new Font(FAMILY, style, size); }

    // ------------------------------------------------------------ trang thai server

    final ServerEngine engine = new ServerEngine(this);

    private JTextField portField;
    private RoundButton startBtn, stopBtn, refreshBtn, clearBtn;
    private JLabel statusChip, dataPathLabel;
    private JLabel statUsers, statOnline, statMail, statBytes;

    private DefaultListModel<String> logModel = new DefaultListModel<>();
    private JList<String> logList;

    private DefaultTableModel usersModel;
    private DefaultTableModel sessionsModel;

    private JTextPane logPane;
    private StyledDocument logDoc;
    private Style styleTime, styleRx, styleTx, styleOk, styleErr, styleInfo;

    private JLabel wireLabel;

    public MailServerGUI() {
        super("Mail Server - Control Panel  (" + MailProtocol.VERSION + ")");

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                engine.stop();
                dispose();
                System.exit(0);
            }
        });

        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);

        root.add(buildTopBar(), BorderLayout.NORTH);
        root.add(buildCenter(), BorderLayout.CENTER);
        root.add(buildWireStrip(), BorderLayout.SOUTH);

        setContentPane(root);
        setSize(1180, 740);
        setMinimumSize(new Dimension(980, 620));
        setLocationRelativeTo(null);

        setStatusStopped();
        refreshStatsAndTables();
    }

    // ============================================================ TOP BAR

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout(14, 0));
        bar.setBackground(PANEL);
        bar.setBorder(new CompoundBorderBottom(BORDER, new EmptyBorder(16, 22, 16, 22)));

        JLabel brand = new JLabel("\u2699  MAIL SERVER");
        brand.setFont(font(Font.BOLD, 16));
        brand.setForeground(TEXT);

        statusChip = new JLabel("DUNG");
        statusChip.setFont(font(Font.BOLD, 12));
        statusChip.setForeground(RED);

        JPanel left = new JPanel(new FlowLayout(FlowLayout.LEFT, 14, 0));
        left.setOpaque(false);
        left.add(brand);
        left.add(statusChip);

        JPanel portBox = new JPanel(new BorderLayout(8, 0));
        portBox.setOpaque(false);
        JLabel portCap = new JLabel("PORT");
        portCap.setFont(font(Font.BOLD, 10));
        portCap.setForeground(MUTED);
        portField = field(String.valueOf(MailProtocol.DEFAULT_PORT));
        portField.setPreferredSize(new Dimension(110, 40));
        portBox.add(portCap, BorderLayout.NORTH);
        portBox.add(portField, BorderLayout.CENTER);

        startBtn   = new RoundButton("\u25B6  START", GREEN, new Color(0x2BC27B), Color.BLACK);
        stopBtn    = new RoundButton("\u25FC  STOP",  RED,   new Color(0xE85858), Color.WHITE);
        refreshBtn = new RoundButton("\u21BB TAI LAI", PANEL_2, BORDER, TEXT);
        clearBtn   = new RoundButton("XOA LOG",     PANEL_2, BORDER, TEXT);
        startBtn.setPreferredSize(new Dimension(130, 40));
        stopBtn.setPreferredSize(new Dimension(130, 40));
        refreshBtn.setPreferredSize(new Dimension(120, 40));
        clearBtn.setPreferredSize(new Dimension(110, 40));

        startBtn.addActionListener(e -> startServer());
        stopBtn.addActionListener(e -> stopServer());
        refreshBtn.addActionListener(e -> refreshStatsAndTables());
        clearBtn.addActionListener(e -> clearLog());

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        right.setOpaque(false);
        right.add(portBox);
        right.add(startBtn);
        right.add(stopBtn);
        right.add(refreshBtn);
        right.add(clearBtn);

        bar.add(left, BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    // ============================================================ CENTER

    private JComponent buildCenter() {
        JPanel panel = new JPanel(new BorderLayout(12, 12));
        panel.setBackground(BG);
        panel.setBorder(new EmptyBorder(16, 20, 16, 20));

        panel.add(buildStatsRow(), BorderLayout.NORTH);
        panel.add(buildBodySplit(), BorderLayout.CENTER);
        return panel;
    }

    // --- thong ke 4 o

    private JPanel buildStatsRow() {
        JPanel row = new JPanel(new GridLayout(1, 4, 14, 0));
        row.setBackground(BG);

        statUsers  = makeStatCard(row, "TONG ACCOUNT", "0", ACCENT, "\uD83D\uDC65");
        statOnline = makeStatCard(row, "DANG ONLINE", "0", GREEN,  "\uD83D\uDFE2");
        statMail   = makeStatCard(row, "TONG EMAIL", "0", AMBER,  "\u2709");
        statBytes  = makeStatCard(row, "BYTE TRAO DOI", "0", new Color(0xA78BFA), "\uD83D\uDCE6");
        return row;
    }

    private JLabel makeStatCard(JPanel parent, String caption, String value, Color dot, String icon) {
        RoundPanel card = new RoundPanel(PANEL, 14);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(16, 18, 16, 18));

        JLabel cap = new JLabel(caption);
        cap.setFont(font(Font.BOLD, 10));
        cap.setForeground(MUTED);
        cap.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel ic = new JLabel(icon + "   ");
        ic.setFont(font(Font.PLAIN, 14));
        ic.setForeground(dot);
        ic.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel val = new JLabel(value);
        val.setFont(font(Font.BOLD, 22));
        val.setForeground(TEXT);
        val.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel lbl = new JLabel();
        lbl.setForeground(TEXT);

        JPanel line = new JPanel(new BorderLayout());
        line.setOpaque(false);
        line.setAlignmentX(Component.LEFT_ALIGNMENT);
        line.add(ic, BorderLayout.WEST);
        line.add(val, BorderLayout.CENTER);

        card.add(cap);
        card.add(Box.createVerticalStrut(10));
        card.add(line);
        card.add(Box.createVerticalGlue());

        parent.add(card);
        return val;
    }

    // --- body: trai = users/sessions, phai = log

    private JComponent buildBodySplit() {
        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT,
                                          buildLeftPane(), buildLogPane());
        split.setDividerLocation(450);
        split.setDividerSize(1);
        split.setBorder(null);
        split.setBackground(BORDER);
        return split;
    }

    // --- trai: 2 tab account & sessions

    private JComponent buildLeftPane() {
        JTabbedPane tabs = new JTabbedPane();
        tabs.setBackground(PANEL);
        tabs.setForeground(TEXT);
        tabs.setFont(font(Font.BOLD, 12));
        tabs.setBorder(null);
        tabs.setUI(new javax.swing.plaf.basic.BasicTabbedPaneUI() {
            @Override protected int calculateTabHeight(int ti, int ih, int fw) {
                return 36;
            }
        });

        JPanel usersTab = new JPanel(new BorderLayout());
        usersTab.setBackground(PANEL);
        usersTab.setBorder(new EmptyBorder(10, 12, 12, 12));
        usersTab.add(buildTablePane(
                usersModel = new DefaultTableModel(
                        new String[]{"Account", "So thu", "Dung luong", "File moi nhat"}, 0) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                },
                new int[]{180, 80, 100, 200}
        ), BorderLayout.CENTER);
        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.setBorder(new EmptyBorder(2, 2, 8, 2));
        JLabel h1 = new JLabel("DANH SACH ACCOUNT DA DANG KY");
        h1.setFont(font(Font.BOLD, 11));
        h1.setForeground(MUTED);
        dataPathLabel = new JLabel("Du lieu: " + ServerEngine.ROOT.toAbsolutePath());
        dataPathLabel.setFont(font(Font.PLAIN, 10));
        dataPathLabel.setForeground(MUTED);
        head.add(h1, BorderLayout.WEST);
        head.add(dataPathLabel, BorderLayout.EAST);
        usersTab.add(head, BorderLayout.NORTH);

        JPanel sessionsTab = new JPanel(new BorderLayout());
        sessionsTab.setBackground(PANEL);
        sessionsTab.setBorder(new EmptyBorder(10, 12, 12, 12));
        sessionsTab.add(buildTablePane(
                sessionsModel = new DefaultTableModel(
                        new String[]{"Account", "Dia chi", "Login luc"}, 0) {
                    @Override public boolean isCellEditable(int r, int c) { return false; }
                },
                new int[]{150, 200, 200}
        ), BorderLayout.CENTER);

        tabs.addTab("  Account  ", usersTab);
        tabs.addTab("  Sessions (dang online)  ", sessionsTab);

        // wrap lai de co background PANEL
        RoundPanel wrap = new RoundPanel(PANEL, 14);
        wrap.setLayout(new BorderLayout());
        wrap.setBorder(new EmptyBorder(0, 0, 0, 0));
        wrap.add(tabs, BorderLayout.CENTER);
        return wrap;
    }

    private JComponent buildTablePane(DefaultTableModel model, int[] widths) {
        JTable t = new JTable(model);
        t.setBackground(PANEL_2);
        t.setForeground(TEXT);
        t.setGridColor(BORDER);
        t.setShowGrid(true);
        t.setIntercellSpacing(new Dimension(1, 1));
        t.setFont(font(Font.PLAIN, 12));
        t.setRowHeight(26);
        t.setSelectionBackground(ACCENT);
        t.setSelectionForeground(Color.WHITE);
        t.setFocusable(false);
        t.getTableHeader().setBackground(PANEL);
        t.getTableHeader().setForeground(TEXT);
        t.getTableHeader().setFont(font(Font.BOLD, 11));
        t.getTableHeader().setBorder(javax.swing.BorderFactory.createLineBorder(BORDER));
        for (int i = 0; i < widths.length; i++) {
            t.getColumnModel().getColumn(i).setMinWidth(widths[i]);
            t.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
        }

        JScrollPane scroll = new JScrollPane(t);
        scroll.setBorder(new RoundLineBorder(BORDER, 10));
        scroll.getViewport().setBackground(PANEL_2);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        styleScrollBar(scroll.getVerticalScrollBar());
        return scroll;
    }

    // --- phai: log

    private JComponent buildLogPane() {
        RoundPanel wrap = new RoundPanel(PANEL, 14);
        wrap.setLayout(new BorderLayout());
        wrap.setBorder(new EmptyBorder(10, 12, 12, 12));

        JPanel head = new JPanel(new BorderLayout());
        head.setOpaque(false);
        head.setBorder(new EmptyBorder(2, 2, 8, 2));
        JLabel h = new JLabel("LOG SERVER");
        h.setFont(font(Font.BOLD, 11));
        h.setForeground(MUTED);
        head.add(h, BorderLayout.WEST);

        logPane = new JTextPane();
        logPane.setBackground(new Color(0x0FAFBFD));
        logPane.setForeground(TEXT);
        logPane.setEditable(false);
        logPane.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 12));
        logPane.setBorder(new EmptyBorder(10, 12, 10, 12));

        logDoc = logPane.getStyledDocument();
        styleTime = logDoc.addStyle("time", null); StyleConstants.setForeground(styleTime, MUTED);
        styleRx   = logDoc.addStyle("rx",   null); StyleConstants.setForeground(styleRx, ACCENT);
        styleTx   = logDoc.addStyle("tx",   null); StyleConstants.setForeground(styleTx, GREEN);
        styleOk   = logDoc.addStyle("ok",   null); StyleConstants.setForeground(styleOk, TEXT);
        styleErr  = logDoc.addStyle("err",  null); StyleConstants.setForeground(styleErr, RED);
        StyleConstants.setBold(styleErr, true);
        styleInfo = logDoc.addStyle("info", null); StyleConstants.setForeground(styleInfo, AMBER);

        JScrollPane scroll = new JScrollPane(logPane);
        scroll.setBorder(new RoundLineBorder(BORDER, 10));
        scroll.getViewport().setBackground(new Color(0x0FAFBFD));
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        styleScrollBar(scroll.getVerticalScrollBar());

        wrap.add(head, BorderLayout.NORTH);
        wrap.add(scroll, BorderLayout.CENTER);
        return wrap;
    }

    // --- wire strip (day nhat phia duoi, hien goi tin cuoi cung)

    private JPanel buildWireStrip() {
        JPanel strip = new JPanel(new BorderLayout());
        strip.setBackground(PANEL_2);
        strip.setBorder(new CompoundBorderTop(BORDER, new EmptyBorder(8, 20, 8, 20)));
        wireLabel = new JLabel("Server san sang, bam START de lang nghe UDP.");
        wireLabel.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        wireLabel.setForeground(MUTED);
        strip.add(wireLabel, BorderLayout.WEST);
        return strip;
    }

    // ============================================================ HANH DONG

    private void startServer() {
        int port;
        try {
            port = Integer.parseInt(portField.getText().trim());
            if (port <= 0 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            logLine(styleErr, "!!! Cong khong hop le: " + portField.getText());
            return;
        }

        portField.setEnabled(false);
        startBtn.setEnabled(false);
        logLine(styleInfo, "[SYSTEM] Khoi dong server tai cong UDP " + port + " ...");
        engine.start(port, ok -> SwingUtilities.invokeLater(() -> {
            if (ok) {
                setStatusRunning(port);
                refreshStatsAndTables();
            } else {
                setStatusStopped();
                startBtn.setEnabled(true);
                portField.setEnabled(true);
            }
        }));
    }

    private void stopServer() {
        logLine(styleInfo, "[SYSTEM] Dung server...");
        engine.stop();
        setStatusStopped();
        portField.setEnabled(true);
        startBtn.setEnabled(true);
        refreshStatsAndTables();
    }

    private void setStatusRunning(int port) {
        statusChip.setText("DANG CHAY  UDP:" + port);
        statusChip.setForeground(GREEN);
        wire("Server dang lang nghe UDP cong " + port);
    }

    private void setStatusStopped() {
        statusChip.setText("DUNG");
        statusChip.setForeground(RED);
        wireLabel.setText("Server khong chay. Bam START de lang nghe.");
    }

    private void clearLog() {
        try { logDoc.remove(0, logDoc.getLength()); } catch (BadLocationException ignored) {}
    }

    /** Cap nhat 4 thong ke + 2 bang account/sessions (goi EDT tu call back) */
    void refreshStatsAndTables() {
        SwingUtilities.invokeLater(() -> {
            try {
                Path root = ServerEngine.ROOT;
                Files.createDirectories(root);
                int totalAccounts = 0, totalMails = 0, totalBytes = 0;
                List<String[]> rows = new ArrayList<>();

                try (Stream<Path> dirs = Files.list(root)) {
                    List<Path> accounts = dirs.filter(Files::isDirectory).toList();
                    totalAccounts = accounts.size();

                    for (Path dir : accounts) {
                        String accName = dir.getFileName().toString();
                        List<Path> files;
                        try (Stream<Path> fs = Files.list(dir)) {
                            files = fs.filter(Files::isRegularFile).sorted(
                                    Comparator.comparing(p -> {
                                        try { return Files.getLastModifiedTime(p); }
                                        catch (IOException e) { return null; }
                                    }, Comparator.nullsLast(Comparator.reverseOrder()))
                            ).toList();
                        }
                        int n = files.size();
                        totalMails += n;
                        long bytes = 0; String newest = "";
                        for (Path f : files) {
                            try { bytes += Files.size(f); } catch (IOException ignored) {}
                            if (f.equals(files.get(0))) newest = f.getFileName().toString();
                        }
                        totalBytes += (int) bytes;
                        rows.add(new String[]{
                                accName,
                                String.valueOf(n),
                                humanSize(bytes),
                                newest
                        });
                    }
                }
                statUsers.setText(String.valueOf(totalAccounts));
                statMail.setText(String.valueOf(totalMails));
                statBytes.setText(humanSize(totalBytes));

                usersModel.setRowCount(0);
                rows.sort((a, b) -> a[0].compareToIgnoreCase(b[0]));
                for (String[] r : rows) usersModel.addRow(r);

                // sessions
                sessionsModel.setRowCount(0);
                for (Map.Entry<String, String> e : engine.snapshotSessions()) {
                    String clientKey = e.getKey();
                    String account = e.getValue();
                    String when = engine.LOGIN_TIME.getOrDefault(clientKey, "-");
                    sessionsModel.addRow(new String[]{account, clientKey, when});
                }
                statOnline.setText(String.valueOf(sessionsModel.getRowCount()));

            } catch (IOException ex) {
                logLine(styleErr, "!!! Loi cap nhat thong ke: " + ex.getMessage());
            }
        });
    }

    private static String humanSize(long bytes) {
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024L * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024L * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.1f GB", bytes / (1024.0 * 1024 * 1024));
    }

    // ============================================================ LOG & WIRE

    /** Them 1 dong log an toan EDT. */
    void logTxRx(String clientKey, String direction, String content) {
        SwingUtilities.invokeLater(() -> {
            appendLog(styleTime, LocalDateTime.now().format(ServerEngine.HUMAN_TIME) + "  ");
            appendLog(styleRx, clientKey + "  ");
            if ("<-".equals(direction)) appendLog(styleRx, direction + "  ");
            else                        appendLog(styleTx, direction + "  ");

            boolean isErr = content.startsWith("ERROR");
            Style s = "<-".equals(direction) ? styleRx
                    : isErr ? styleErr : styleTx;
            appendLog(s, content.replace("\n", "␤"));
            appendLog(styleOk, "\n");

            // goi tin cuoi cung len wire
            String pre = content.replace("\n", "\\n");
            wire((clientKey + " " + direction + " " +
                  (pre.length() > 160 ? pre.substring(0, 160) + "..." : pre)));

            refreshStatsAndTables();
        });
    }

    void logLine(Style style, String text) {
        SwingUtilities.invokeLater(() -> {
            appendLog(styleTime, LocalDateTime.now().format(ServerEngine.HUMAN_TIME) + "  ");
            appendLog(style, text);
            appendLog(styleOk, "\n");
        });
    }

    private void appendLog(Style style, String text) {
        try {
            logDoc.insertString(logDoc.getLength(), text, style);
            if (logPane.getParent() != null) {
                logPane.setCaretPosition(logDoc.getLength());
            }
        } catch (BadLocationException ignored) {}
    }

    private void wire(String t) { wireLabel.setText(t); }

    // ============================================================ TIEN ICH GIAO DIEN

    private static JTextField field(String value) {
        JTextField f = new JTextField(value);
        f.setFont(font(Font.PLAIN, 13));
        f.setForeground(TEXT);
        f.setCaretColor(TEXT);
        f.setBackground(PANEL_2);
        f.setBorder(new CompoundBorderPad(new RoundLineBorder(BORDER, 9), 12));
        return f;
    }

    private static void styleScrollBar(JScrollBar bar) {
        bar.setUnitIncrement(16);
        bar.setBackground(BG);
        bar.setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor = new Color(0x3A4151);
                trackColor = BG;
            }
            @Override protected JButton createDecreaseButton(int o) { return zeroButton(); }
            @Override protected JButton createIncreaseButton(int o) { return zeroButton(); }
            private JButton zeroButton() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
        bar.setPreferredSize(new Dimension(8, 0));
    }

    // ============================================================ MAIN

    public static void main(String[] args) {
        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        SwingUtilities.invokeLater(() -> {
            UIManager.put("ToolTip.background", PANEL_2);
            UIManager.put("ToolTip.foreground", TEXT);
            new MailServerGUI().setVisible(true);
        });
    }

    // ============================================================ SERVER ENGINE

    /**
     * Thread doc lap chay logic Server (DatagramSocket receive loop) +
     * goi cac callback len EDT de update GUI.
     *
     * Toan bo logic register/login/send/list/read o day giong 100% MailServer.java
     * ban console (giu giao thuc MAIL/1.0 hoan toan tuong thich voi Client cu).
     */
    static class ServerEngine {
        static final Path ROOT = Paths.get("mailserver_data");
        /** File luu username, hash mat khau va thong tin tao/dang nhap gan nhat. */
        static final String ACCOUNT_CRED = "account.cred";
        static final DateTimeFormatter FILE_STAMP =
                DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");
        static final DateTimeFormatter HUMAN_TIME =
                DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

        private final MailServerGUI gui;

        final ConcurrentHashMap<String, String> sessions = new ConcurrentHashMap<>();
        final ConcurrentHashMap<String, String> LOGIN_TIME = new ConcurrentHashMap<>();

        /** Luu dia chi remote cho push notify. */
        final Map<String, InetAddress> clientAddress = new ConcurrentHashMap<>();
        final Map<String, Integer>     clientPort    = new ConcurrentHashMap<>();
        /** Account -> tap hop clientKey dang online. */
        final Map<String, Set<String>> accountClients = new ConcurrentHashMap<>();
        /** Hang doi thong bao push can gui sau reply. */
        final Queue<PendingNotify> notifyQueue = new ConcurrentLinkedQueue<>();

        /** Goi thong bao push cho 1 client. */
        static final class PendingNotify {
            final InetAddress addr;
            final int         port;
            final String      message;
            PendingNotify(InetAddress a, int p, String m) { addr = a; port = p; message = m; }
        }

        private volatile Thread worker;
        private volatile DatagramSocket socket;

        ServerEngine(MailServerGUI gui) { this.gui = gui; }

        // --- chay 1 thread worker, callback ve EDT khi xonog
        synchronized void start(int port, java.util.function.Consumer<Boolean> onReady) {
            if (worker != null && worker.isAlive()) { onReady.accept(true); return; }

            worker = new Thread(() -> {
                DatagramSocket s;
                try {
                    Files.createDirectories(ROOT);
                    s = new DatagramSocket(port);
                    s.setSoTimeout(1500);     // de co the kiem tra dieu kien dung
                    socket = s;
                } catch (IOException e) {
                    gui.logLine(gui.styleErr, "!!! Khong the mo cong " + port + ": " + e.getMessage());
                    socket = null;
                    onReady.accept(false);
                    return;
                }
                onReady.accept(true);
                gui.logLine(gui.styleOk, "[SYSTEM] Server STARTED: " + MailProtocol.VERSION
                                            + "  port UDP " + port + "  path=" + ROOT.toAbsolutePath());

                byte[] buffer = new byte[MailProtocol.MAX_DATAGRAM];
                while (!Thread.interrupted() && socket != null && !socket.isClosed()) {
                    try {
                        DatagramPacket p = new DatagramPacket(buffer, buffer.length);
                        try { s.receive(p); }
                        catch (SocketException se) {
                            if (socket == null || socket.isClosed()) break;
                            throw se;
                        } catch (java.net.SocketTimeoutException ste) {
                            continue;
                        }

                        String raw = new String(p.getData(), 0, p.getLength(),
                                                StandardCharsets.UTF_8);
                        String clientKey = p.getAddress().getHostAddress() + ":" + p.getPort();

                        // Luu dia chi remote de gui thong bao push sau nay
                        clientAddress.put(clientKey, p.getAddress());
                        clientPort.put(clientKey, p.getPort());

                        MailProtocol.Request req;
                        String reply;
                        try {
                            req = MailProtocol.parseRequest(raw);
                            gui.logTxRx(clientKey, "<-", req.toString());
                            reply = dispatch(req, clientKey);
                        } catch (MailProtocol.ProtocolException e) {
                            gui.logTxRx(clientKey, "<-", "(Loi goi tin) " + e.getMessage());
                            reply = MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                                                               e.getMessage());
                        } catch (Exception e) {
                            reply = MailProtocol.buildResponse(MailProtocol.SERVER_ERROR,
                                    "Loi server: " + e.getMessage());
                        }

                        byte[] out = reply.getBytes(StandardCharsets.UTF_8);
                        if (out.length > MailProtocol.MAX_DATAGRAM) {
                            reply = MailProtocol.buildResponse(MailProtocol.SERVER_ERROR,
                                    "Du lieu tra ve vuot " + MailProtocol.MAX_DATAGRAM + " byte");
                            out = reply.getBytes(StandardCharsets.UTF_8);
                        }

                        s.send(new DatagramPacket(out, out.length,
                                                  p.getAddress(), p.getPort()));
                        gui.logTxRx(clientKey, "->", summarize(reply));

                        // Gui thong bao push (NEW_MAIL) trong hang doi (neu co)
                        PendingNotify pn;
                        while ((pn = notifyQueue.poll()) != null) {
                            byte[] nd = pn.message.getBytes(StandardCharsets.UTF_8);
                            if (nd.length > MailProtocol.MAX_DATAGRAM) continue;
                            try {
                                s.send(new DatagramPacket(nd, nd.length, pn.addr, pn.port));
                                String key = pn.addr.getHostAddress() + ":" + pn.port;
                                gui.logTxRx(key, "=>", "(thong bao) " + summarize(pn.message));
                            } catch (IOException ignored) { }
                        }

                    } catch (IOException ioe) {
                        if (socket == null || socket.isClosed()) break;
                        gui.logLine(gui.styleErr, "!!! I/O: " + ioe.getMessage());
                    }
                }

                gui.logLine(gui.styleInfo, "[SYSTEM] Loop receiver da thoat.");
            }, "MailServer-Worker");
            worker.setDaemon(true);
            worker.start();
        }

        synchronized void stop() {
            if (socket != null && !socket.isClosed()) socket.close();
            if (worker != null) { worker.interrupt(); worker = null; }
            sessions.clear();
            LOGIN_TIME.clear();
            accountClients.clear();
            clientAddress.clear();
            clientPort.clear();
            notifyQueue.clear();
            gui.logLine(gui.styleInfo, "[SYSTEM] STOPPED - tat ca session da clear.");
        }

        /** Snap de hien thi bang sessions tren EDT */
        List<Map.Entry<String, String>> snapshotSessions() {
            List<Map.Entry<String, String>> list = new ArrayList<>(sessions.entrySet());
            list.sort(Comparator.comparing(e -> e.getValue() == null ? "" : e.getValue()));
            return list;
        }

        // -------------------------------------------------------- logic goi tin

        private String dispatch(MailProtocol.Request req, String clientKey) throws IOException {
            switch (req.command) {
                case MailProtocol.CMD_REGISTER: {
                    if (req.argCount() < 2) {
                        return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                                "Cu phap: REGISTER|account|mat_khau");
                    }
                    return register(req.arg(0), req.arg(1));
                }
                case MailProtocol.CMD_LOGIN: {
                    if (req.argCount() < 2) {
                        return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                                "Cu phap: LOGIN|account|mat_khau");
                    }
                    return login(req.arg(0), req.arg(1), clientKey);
                }

                case MailProtocol.CMD_SEND:
                    if (req.argCount() < 3) {
                        return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                                "Cu phap: SEND|nguoi_nhan|tieu_de|noi_dung");
                    }
                    return send(sessions.get(clientKey), req.arg(0), req.arg(1), req.arg(2));

                case MailProtocol.CMD_LIST: return list(sessions.get(clientKey));
                case MailProtocol.CMD_READ: return read(sessions.get(clientKey), req.arg(0));

                case MailProtocol.CMD_LOGOUT: {
                    String account = sessions.remove(clientKey);
                    LOGIN_TIME.remove(clientKey);
                    if (account != null) {
                        Set<String> set = accountClients.get(account);
                        if (set != null) {
                            set.remove(clientKey);
                            if (set.isEmpty()) accountClients.remove(account);
                        }
                    }
                    clientAddress.remove(clientKey);
                    clientPort.remove(clientKey);
                    return MailProtocol.buildResponse(MailProtocol.OK, "Da dang xuat");
                }

                case MailProtocol.CMD_PING:
                    return MailProtocol.buildResponse(MailProtocol.OK, "pong");

                default:
                    return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                            "Lenh khong ho tro: " + req.command);
            }
        }

        private String register(String account, String password) throws IOException {
            if (!MailProtocol.isValidAccount(account)) {
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Ten account khong hop le (chi cho chu, so, . _ -)");
            }
            if (!MailProtocol.isValidPassword(password)) {
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Mat khau dai it nhat 4 ky tu va toi da 32 ky tu");
            }
            Path dir = ROOT.resolve(account);
            if (Files.exists(dir)) {
                return MailProtocol.buildResponse(MailProtocol.CONFLICT,
                        "Account '" + account + "' da ton tai");
            }
            Files.createDirectories(dir);
            AccountCredentials.write(dir.resolve(ACCOUNT_CRED), account,
                    password, AccountCredentials.now(), "", 0);
            Files.write(dir.resolve(MailProtocol.WELCOME_FILE),
                        MailProtocol.WELCOME_TEXT.getBytes(StandardCharsets.UTF_8));
            return MailProtocol.buildResponse(MailProtocol.OK,
                    "Da tao account '" + account + "'");
        }

        private String login(String account, String password, String clientKey) throws IOException {
            if (!MailProtocol.isValidAccount(account)) {
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Ten account khong hop le");
            }
            if (!MailProtocol.isValidPassword(password)) {
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Mat khau dai it nhat 4 ky tu va toi da 32 ky tu");
            }
            Path dir = ROOT.resolve(account);
            if (!Files.isDirectory(dir)) {
                return MailProtocol.buildResponse(MailProtocol.NOT_FOUND,
                        "Account '" + account + "' chua ton tai");
            }

            Path credFile = dir.resolve(ACCOUNT_CRED);
            String storedPassword;
            String createdAt;
            if (!Files.isRegularFile(credFile)) {
                // Account cu chua co credential: mat khau mac dinh la ten account
                storedPassword = account;
                if (!MailProtocol.hashPassword(storedPassword)
                        .equals(MailProtocol.hashPassword(password))) {
                    return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                            "Sai mat khau (account cu mac dinh dung ten account lam mk)");
                }
                createdAt = Files.readAttributes(dir,
                        java.nio.file.attribute.BasicFileAttributes.class)
                        .creationTime().toInstant().toString();
            } else {
                AccountCredentials.Credential credential =
                        AccountCredentials.read(credFile, account);
                storedPassword = credential.password;
                createdAt = credential.createdAt;
                boolean passwordMatches = credential.legacyHash
                        ? storedPassword.equals(MailProtocol.hashPassword(password))
                        : storedPassword.equals(password);
                if (!passwordMatches) {
                    return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                            "Sai mat khau");
                }
            }

            AccountCredentials.write(credFile, account, password, createdAt,
                    AccountCredentials.ipFromClientKey(clientKey),
                    AccountCredentials.portFromClientKey(clientKey));
            sessions.put(clientKey, account);
            LOGIN_TIME.put(clientKey, LocalDateTime.now().format(HUMAN_TIME));
            accountClients.computeIfAbsent(account, k -> new HashSet<>()).add(clientKey);

            List<String> files = fileNames(dir);
            return MailProtocol.buildResponse(MailProtocol.OK,
                    "Dang nhap thanh cong voi '" + account + "'",
                    files.toArray(new String[0]));
        }

        private String send(String sender, String receiver, String subject, String body)
                throws IOException {
            if (sender == null) {
                return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                        "Ban chua dang nhap");
            }
            if (!MailProtocol.isValidAccount(receiver)) {
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Ten nguoi nhan khong hop le");
            }
            Path dir = ROOT.resolve(receiver);
            if (!Files.isDirectory(dir)) {
                return MailProtocol.buildResponse(MailProtocol.NOT_FOUND,
                        "Nguoi nhan '" + receiver + "' khong ton tai");
            }
            LocalDateTime now = LocalDateTime.now();
            Path file = dir.resolve("mail_" + now.format(FILE_STAMP) + ".txt");
            String content = "From: "    + sender   + System.lineSeparator()
                           + "To: "      + receiver + System.lineSeparator()
                           + "Subject: " + subject  + System.lineSeparator()
                           + "Date: "    + now.format(HUMAN_TIME) + System.lineSeparator()
                           + System.lineSeparator()
                           + body;
            Files.write(file, content.getBytes(StandardCharsets.UTF_8));

            // Push thong bao den tat ca cua so dang dang nhap cua nguoi nhan
            String fileName = file.getFileName().toString();
            Set<String> onlineKeys = accountClients.get(receiver);
            if (onlineKeys != null && !onlineKeys.isEmpty()) {
                String notifyMsg = MailProtocol.buildRequest(
                        MailProtocol.CMD_NOTIFY, "NEW_MAIL", fileName, sender, subject);
                for (String key : onlineKeys) {
                    InetAddress a = clientAddress.get(key);
                    Integer     p = clientPort.get(key);
                    if (a != null && p != null) {
                        notifyQueue.add(new PendingNotify(a, p, notifyMsg));
                    }
                }
            }

            return MailProtocol.buildResponse(MailProtocol.OK,
                    "Da gui email toi '" + receiver + "'",
                    file.getFileName().toString());
        }

        private String list(String account) throws IOException {
            if (account == null) {
                return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                        "Ban chua dang nhap");
            }
            List<String> files = fileNames(ROOT.resolve(account));
            return MailProtocol.buildResponse(MailProtocol.OK,
                    "Hop thu cua '" + account + "'",
                    files.toArray(new String[0]));
        }

        private String read(String account, String fileName) throws IOException {
            if (account == null) {
                return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                        "Ban chua dang nhap");
            }
            if (!MailProtocol.isValidFileName(fileName)) {
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Ten file khong hop le");
            }
            Path file = ROOT.resolve(account).resolve(fileName);
            if (!Files.isRegularFile(file)) {
                return MailProtocol.buildResponse(MailProtocol.NOT_FOUND,
                        "Khong tim thay '" + fileName + "'");
            }
            String c = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
            return MailProtocol.buildResponse(MailProtocol.OK, fileName, c);
        }

        private static List<String> fileNames(Path dir) throws IOException {
            List<String> names = new ArrayList<>();
            try (Stream<Path> stream = Files.list(dir)) {
                stream.filter(Files::isRegularFile)
                      .forEach(p -> names.add(p.getFileName().toString()));
            }
            Collections.sort(names);
            return names;
        }

        private static String summarize(String reply) {
            String s = reply.replace("\n", " ");
            return s.length() > 120 ? s.substring(0, 120) + "..." : s;
        }
    }

    // ============================================================ THANH PHAN TU VE

    static class RoundPanel extends JPanel {
        private final Color color; private final int radius;
        RoundPanel(Color color, int radius) {
            this.color = color; this.radius = radius;
            setOpaque(false);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    static class RoundButton extends JButton {
        private final Color base, hover;
        RoundButton(String text, Color base, Color hover, Color fg) {
            super(text);
            this.base = base; this.hover = hover;
            setForeground(fg);
            setFont(font(Font.BOLD, 12));
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setBorder(new EmptyBorder(8, 16, 8, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = getModel().isEnabled()
                    ? (getModel().isRollover() ? hover : base)
                    : BORDER;
            g2.setColor(c);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 9, 9);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    static class RoundLineBorder extends AbstractBorder {
        private final Color color; private final int radius;
        RoundLineBorder(Color color, int radius) { this.color = color; this.radius = radius; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                                RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w - 1, h - 1, radius, radius);
            g2.dispose();
        }
        @Override public Insets getBorderInsets(Component c) { return new Insets(1, 1, 1, 1); }
    }

    static class CompoundBorderPad extends AbstractBorder {
        private final AbstractBorder outer; private final int pad;
        CompoundBorderPad(AbstractBorder outer, int pad) {
            this.outer = outer; this.pad = pad;
        }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            outer.paintBorder(c, g, x, y, w, h);
        }
        @Override public Insets getBorderInsets(Component c) {
            return new Insets(pad, pad, pad, pad);
        }
    }

    static class CompoundBorderBottom extends AbstractBorder {
        private final Color line; private final EmptyBorder pad;
        CompoundBorderBottom(Color line, EmptyBorder pad) { this.line = line; this.pad = pad; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            g.setColor(line); g.fillRect(x, y + h - 1, w, 1);
        }
        @Override public Insets getBorderInsets(Component c) { return pad.getBorderInsets(c); }
    }

    static class CompoundBorderTop extends AbstractBorder {
        private final Color line; private final EmptyBorder pad;
        CompoundBorderTop(Color line, EmptyBorder pad) { this.line = line; this.pad = pad; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            g.setColor(line); g.fillRect(x, y, w, 1);
        }
        @Override public Insets getBorderInsets(Component c) { return pad.getBorderInsets(c); }
    }
}
