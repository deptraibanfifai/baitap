package com.library;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.stream.Stream;

/**
 * Bai 2 - Mail Server chay tren UDP, noi giao thuc MAIL/1.0 (xem MailProtocol).
 *
 * Chay:  java MailServer          -> cong mac dinh 2346
 *        java MailServer 5000     -> chi dinh cong khac
 *
 * Toan bo thu duoc luu trong thu muc ./mailserver_data/<account>/
 */
public class MailServer {

    private static final Path ROOT = Paths.get("mailserver_data");
    /** File luu username, hash mat khau va thong tin tao/dang nhap gan nhat. */
    private static final String ACCOUNT_CRED = "account.cred";

    private static final DateTimeFormatter FILE_STAMP =
            DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss_SSS");
    private static final DateTimeFormatter HUMAN_TIME =
            DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");

    /** Phien dang nhap: "ip:port" -> ten account. UDP khong co ket noi nen phai tu nho. */
    private static final Map<String, String> sessions = new HashMap<>();

    /** Luu dia chi remote tung client de co the gui thong bao (push) ve sau. */
    private static final Map<String, InetAddress> clientAddress = new HashMap<>();
    private static final Map<String, Integer>     clientPort    = new HashMap<>();

    /** Account -> cac clientKey hien dang dang nhap vao account do. */
    private static final Map<String, Set<String>> accountClients = new HashMap<>();

    /** Gói tin thông báo cần gửi sau khi đã gửi reply cho request hiện tại. */
    private static final Queue<PendingNotify> notifyQueue = new ConcurrentLinkedQueue<>();

    /** Một thông báo cần gửi đến một client cụ thể. */
    static final class PendingNotify {
        final InetAddress addr;
        final int         port;
        final String      message;
        PendingNotify(InetAddress a, int p, String m) { addr = a; port = p; message = m; }
    }

    public static void main(String[] args) throws IOException {
        int port = (args.length > 0) ? Integer.parseInt(args[0]) : MailProtocol.DEFAULT_PORT;

        Files.createDirectories(ROOT);

        DatagramSocket socket = new DatagramSocket(port);
        System.out.println("=== MAIL SERVER (" + MailProtocol.VERSION + ") ===");
        System.out.println("Lang nghe UDP cong : " + port);
        System.out.println("Thu muc du lieu    : " + ROOT.toAbsolutePath());
        System.out.println();

        byte[] buffer = new byte[MailProtocol.MAX_DATAGRAM];

        while (true) {
            DatagramPacket packet = new DatagramPacket(buffer, buffer.length);
            socket.receive(packet);   // chan tai day cho den khi co goi tin

            String raw = new String(packet.getData(), 0, packet.getLength(),
                                    StandardCharsets.UTF_8);
            String clientKey = packet.getAddress().getHostAddress() + ":" + packet.getPort();

            // Luu dia chi remote cua client nay vao danh sach - danh cho gui thong bao push
            clientAddress.put(clientKey, packet.getAddress());
            clientPort.put(clientKey, packet.getPort());

            String reply;
            try {
                MailProtocol.Request request = MailProtocol.parseRequest(raw);
                log(clientKey, "<-", request.toString());
                reply = dispatch(request, clientKey);

            } catch (MailProtocol.ProtocolException e) {
                log(clientKey, "<-", "(goi tin loi) " + e.getMessage());
                reply = MailProtocol.buildResponse(MailProtocol.BAD_REQUEST, e.getMessage());

            } catch (Exception e) {
                reply = MailProtocol.buildResponse(MailProtocol.SERVER_ERROR,
                                                   "Loi server: " + e.getMessage());
            }

            byte[] data = reply.getBytes(StandardCharsets.UTF_8);
            if (data.length > MailProtocol.MAX_DATAGRAM) {
                // Vuot kich thuoc mot datagram -> bao loi thay vi gui goi tin bi cat
                reply = MailProtocol.buildResponse(MailProtocol.SERVER_ERROR,
                        "Du lieu tra ve vuot qua " + MailProtocol.MAX_DATAGRAM + " byte");
                data = reply.getBytes(StandardCharsets.UTF_8);
            }

            socket.send(new DatagramPacket(data, data.length,
                                           packet.getAddress(), packet.getPort()));
            log(clientKey, "->", summarize(reply));

            // Sau khi gui reply xong, gui tiep cac goi thong bao (NEW_MAIL...) trong hang doi
            PendingNotify pn;
            while ((pn = notifyQueue.poll()) != null) {
                byte[] nd = pn.message.getBytes(StandardCharsets.UTF_8);
                if (nd.length > MailProtocol.MAX_DATAGRAM) continue;
                try {
                    socket.send(new DatagramPacket(nd, nd.length, pn.addr, pn.port));
                    String remoteKey = pn.addr.getHostAddress() + ":" + pn.port;
                    log(remoteKey, "=>", "(thong bao) " + summarize(pn.message));
                } catch (IOException ignored) { }
            }
        }
    }

    /** Dieu huong theo lenh trong goi tin. */
    private static String dispatch(MailProtocol.Request req, String clientKey)
            throws IOException {

        switch (req.command) {
            case MailProtocol.CMD_REGISTER: {
                if (req.argCount() < 2) {
                    return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                            "Cu phap: REGISTER|account|mat_khau");
                }
                return register(req.arg(0), req.arg(1));
            }
            case MailProtocol.CMD_LOGIN: {
                if (req.argCount() < 2) {
                    return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                            "Cu phap: LOGIN|account|mat_khau");
                }
                return login(req.arg(0), req.arg(1), clientKey);
            }

            case MailProtocol.CMD_SEND:
                if (req.argCount() < 3) {
                    return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                            "Cu phap: SEND|nguoi_nhan|tieu_de|noi_dung");
                }
                return send(sessions.get(clientKey), req.arg(0), req.arg(1), req.arg(2));

            case MailProtocol.CMD_LIST:     return list(sessions.get(clientKey));
            case MailProtocol.CMD_READ:     return read(sessions.get(clientKey), req.arg(0));

            case MailProtocol.CMD_LOGOUT: {
                String account = sessions.remove(clientKey);
                if (account != null) {
                    Set<String> set = accountClients.get(account);
                    if (set != null) {
                        set.remove(clientKey);
                        if (set.isEmpty()) accountClients.remove(account);
                    }
                }
                clientAddress.remove(clientKey);
                clientPort.remove(clientKey);
                return MailProtocol.buildResponse(MailProtocol.OK, "Da dang xuat");
            }

            case MailProtocol.CMD_PING:
                return MailProtocol.buildResponse(MailProtocol.OK, "pong");

            default:
                return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                        "Lenh khong ho tro: " + req.command);
        }
    }

    // ------------------------------------------------------------ chuc nang

    /**
     * Yeu cau 1 cua de bai (co them mat khau): tao account moi -> tao thu muc
     * tuong ung tren server, luu thong tin credential vao account.cred va tao
     * file new_email.txt chua loi chao.
     */
    private static String register(String account, String password) throws IOException {
        if (!MailProtocol.isValidAccount(account)) {
            return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                    "Ten account khong hop le (chi cho chu, so, . _ -)");
        }
        if (!MailProtocol.isValidPassword(password)) {
            return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                    "Mat khau dai it nhat 4 ky tu va toi da 32 ky tu");
        }

        Path dir = ROOT.resolve(account);
        if (Files.exists(dir)) {
            return MailProtocol.buildResponse(MailProtocol.CONFLICT,
                    "Account '" + account + "' da ton tai");
        }

        Files.createDirectories(dir);
        AccountCredentials.write(dir.resolve(ACCOUNT_CRED), account,
                password, AccountCredentials.now(), "", 0);
        Files.write(dir.resolve(MailProtocol.WELCOME_FILE),
                    MailProtocol.WELCOME_TEXT.getBytes(StandardCharsets.UTF_8));

        return MailProtocol.buildResponse(MailProtocol.OK,
                "Da tao account '" + account + "'");
    }

    /**
     * Yeu cau 3 cua de bai (co them mat khau): dang nhap -> xac thuc mat khau
     * tren server, neu dung thi mo thu muc account va gui ve ten file.
     * Ho tro chuyen doi tu phien ban cu (chua co mat khau): neu file
     * account.cred chua ton tai thi mat khau mac dinh chinh la ten account.
     */
    private static String login(String account, String password, String clientKey)
            throws IOException {
        if (!MailProtocol.isValidAccount(account)) {
            return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                    "Ten account khong hop le");
        }
        if (!MailProtocol.isValidPassword(password)) {
            return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                    "Mat khau dai it nhat 4 ky tu va toi da 32 ky tu");
        }

        Path dir = ROOT.resolve(account);
        if (!Files.isDirectory(dir)) {
            return MailProtocol.buildResponse(MailProtocol.NOT_FOUND,
                    "Account '" + account + "' chua ton tai");
        }

        Path credFile = dir.resolve(ACCOUNT_CRED);
        String storedPassword;
        String createdAt;

        if (!Files.isRegularFile(credFile)) {
            // Account cu (tao truoc khi co phien ban mat khau) -> mat khau mac dinh
            // la ten account. Sau khi dang nhap thanh cong luu lai credential.
            storedPassword = account;
            if (!MailProtocol.hashPassword(storedPassword)
                    .equals(MailProtocol.hashPassword(password))) {
                return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                        "Sai mat khau (account cu mac dinh dung ten account lam mk)");
            }
            createdAt = Files.readAttributes(dir,
                    java.nio.file.attribute.BasicFileAttributes.class)
                    .creationTime().toInstant().toString();
        } else {
            AccountCredentials.Credential credential =
                    AccountCredentials.read(credFile, account);
            storedPassword = credential.password;
            createdAt = credential.createdAt;
            boolean passwordMatches = credential.legacyHash
                    ? storedPassword.equals(MailProtocol.hashPassword(password))
                    : storedPassword.equals(password);
            if (!passwordMatches) {
                return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                        "Sai mat khau");
            }
        }

        AccountCredentials.write(credFile, account, password, createdAt,
                AccountCredentials.ipFromClientKey(clientKey),
                AccountCredentials.portFromClientKey(clientKey));
        sessions.put(clientKey, account);

        // Danh dau clientKey nay la mot cua so dang online cua account nay
        accountClients.computeIfAbsent(account, k -> new HashSet<>()).add(clientKey);

        List<String> files = fileNames(dir);

        return MailProtocol.buildResponse(MailProtocol.OK,
                "Dang nhap thanh cong voi '" + account + "'",
                files.toArray(new String[0]));
    }

    /**
     * Yeu cau 2 cua de bai: nhan email, xac dinh account nguoi nhan,
     * tao file moi trong thu muc cua account do voi noi dung la noi dung email.
     */
    private static String send(String sender, String receiver, String subject, String body)
            throws IOException {

        if (sender == null) {
            return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED,
                    "Ban chua dang nhap");
        }
        if (!MailProtocol.isValidAccount(receiver)) {
            return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                    "Ten nguoi nhan khong hop le");
        }

        Path dir = ROOT.resolve(receiver);
        if (!Files.isDirectory(dir)) {
            return MailProtocol.buildResponse(MailProtocol.NOT_FOUND,
                    "Nguoi nhan '" + receiver + "' khong ton tai");
        }

        // Ten file theo thoi diem gui (den mili-giay) nen khong bao gio ghi de nhau
        LocalDateTime now = LocalDateTime.now();
        Path file = dir.resolve("mail_" + now.format(FILE_STAMP) + ".txt");

        String content = "From: "    + sender   + System.lineSeparator()
                       + "To: "      + receiver + System.lineSeparator()
                       + "Subject: " + subject  + System.lineSeparator()
                       + "Date: "    + now.format(HUMAN_TIME) + System.lineSeparator()
                       + System.lineSeparator()
                       + body;

        Files.write(file, content.getBytes(StandardCharsets.UTF_8));

        // Nguoi nhan dang online -> gui thong bao den tat ca cua so dang dang nhap
        String fileName = file.getFileName().toString();
        Set<String> onlineKeys = accountClients.get(receiver);
        if (onlineKeys != null && !onlineKeys.isEmpty()) {
            String notifyMsg = MailProtocol.buildRequest(
                    MailProtocol.CMD_NOTIFY, "NEW_MAIL", fileName, sender, subject);
            for (String key : onlineKeys) {
                InetAddress a = clientAddress.get(key);
                Integer     p = clientPort.get(key);
                if (a != null && p != null) {
                    notifyQueue.add(new PendingNotify(a, p, notifyMsg));
                }
            }
        }

        return MailProtocol.buildResponse(MailProtocol.OK,
                "Da gui email toi '" + receiver + "'",
                file.getFileName().toString());
    }

    /** Lay lai danh sach file trong hop thu cua account dang dang nhap. */
    private static String list(String account) throws IOException {
        if (account == null) {
            return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED, "Ban chua dang nhap");
        }

        List<String> files = fileNames(ROOT.resolve(account));
        return MailProtocol.buildResponse(MailProtocol.OK,
                "Hop thu cua '" + account + "'",
                files.toArray(new String[0]));
    }

    /** Doc noi dung mot file trong hop thu cua account dang dang nhap. */
    private static String read(String account, String fileName) throws IOException {
        if (account == null) {
            return MailProtocol.buildResponse(MailProtocol.UNAUTHORIZED, "Ban chua dang nhap");
        }
        if (!MailProtocol.isValidFileName(fileName)) {
            return MailProtocol.buildResponse(MailProtocol.BAD_REQUEST,
                    "Ten file khong hop le");
        }

        Path file = ROOT.resolve(account).resolve(fileName);
        if (!Files.isRegularFile(file)) {
            return MailProtocol.buildResponse(MailProtocol.NOT_FOUND,
                    "Khong tim thay '" + fileName + "'");
        }

        String content = new String(Files.readAllBytes(file), StandardCharsets.UTF_8);
        return MailProtocol.buildResponse(MailProtocol.OK, fileName, content);
    }

    // ------------------------------------------------------------ tien ich

    private static List<String> fileNames(Path dir) throws IOException {
        List<String> names = new ArrayList<>();
        try (Stream<Path> stream = Files.list(dir)) {
            stream.filter(Files::isRegularFile)
                  .forEach(p -> names.add(p.getFileName().toString()));
        }
        Collections.sort(names);
        return names;
    }

    private static void log(String client, String arrow, String text) {
        System.out.println("[" + LocalDateTime.now().format(HUMAN_TIME) + "] "
                         + client + " " + arrow + " " + text);
    }

    private static String summarize(String reply) {
        String s = reply.replace("\n", " ");
        return s.length() > 90 ? s.substring(0, 90) + "..." : s;
    }
}
