package com.library;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.Scanner;

/**
 * Bai 2 - Mail Client phien ban dong lenh (noi giao thuc MAIL/1.0).
 * Ban co giao dien do hoa nam trong MailClientGUI.java
 *
 * Chay:  java MailClient
 *        java MailClient 192.168.1.5
 *        java MailClient 192.168.1.5 5000
 */
public class MailClient {

    private static final int TIMEOUT_MS = 3000;
    private static final int RETRIES    = 2;      // UDP co the mat goi -> thu lai

    private static DatagramSocket socket;
    private static InetAddress    serverAddress;
    private static int            serverPort;
    private static String         currentAccount = null;

    public static void main(String[] args) throws Exception {
        String host = (args.length > 0) ? args[0] : "127.0.0.1";
        serverPort  = (args.length > 1) ? Integer.parseInt(args[1]) : MailProtocol.DEFAULT_PORT;
        serverAddress = InetAddress.getByName(host);

        socket = new DatagramSocket();
        socket.setSoTimeout(TIMEOUT_MS);

        System.out.println("MailClient -> " + host + ":" + serverPort
                         + "  (" + MailProtocol.VERSION + ")");

        Scanner sc = new Scanner(System.in, "UTF-8");

        while (true) {
            printMenu();
            System.out.print("Chon: ");
            if (!sc.hasNextLine()) break;

            switch (sc.nextLine().trim()) {
                case "1": doRegister(sc); break;
                case "2": doLogin(sc);    break;
                case "3": doSend(sc);     break;
                case "4": doList();       break;
                case "5": doRead(sc);     break;
                case "6": doLogout();     break;
                case "0":
                    socket.close();
                    System.out.println("Tam biet.");
                    return;
                default:
                    System.out.println("Lua chon khong hop le.");
            }
        }
        socket.close();
    }

    private static void printMenu() {
        System.out.println("\n===== MAIL CLIENT ====="
                + (currentAccount == null ? "" : "  [" + currentAccount + "]"));
        System.out.println("1. Tao account moi");
        System.out.println("2. Dang nhap");
        System.out.println("3. Gui email");
        System.out.println("4. Xem hop thu");
        System.out.println("5. Doc mot email");
        System.out.println("6. Dang xuat");
        System.out.println("0. Thoat");
    }

    // ------------------------------------------------------------ thao tac

    private static void doRegister(Scanner sc) {
        System.out.print("Ten account: ");
        String account = sc.nextLine().trim();
        show(call(MailProtocol.buildRequest(MailProtocol.CMD_REGISTER, account)));
    }

    private static void doLogin(Scanner sc) {
        System.out.print("Ten account: ");
        String account = sc.nextLine().trim();

        MailProtocol.Response res = call(MailProtocol.buildRequest(
                MailProtocol.CMD_LOGIN, account));

        if (res != null && res.isOk()) currentAccount = account;
        show(res);
    }

    private static void doSend(Scanner sc) {
        if (requireLogin()) return;

        System.out.print("Gui toi account: ");
        String receiver = sc.nextLine().trim();
        System.out.print("Tieu de: ");
        String subject = sc.nextLine().trim();

        System.out.println("Noi dung (go mot dong trong de ket thuc):");
        StringBuilder body = new StringBuilder();
        String line;
        while (sc.hasNextLine() && !(line = sc.nextLine()).isEmpty()) {
            if (body.length() > 0) body.append('\n');
            body.append(line);
        }

        show(call(MailProtocol.buildRequest(
                MailProtocol.CMD_SEND, receiver, subject, body.toString())));
    }

    private static void doList() {
        if (requireLogin()) return;
        show(call(MailProtocol.buildRequest(MailProtocol.CMD_LIST)));
    }

    private static void doRead(Scanner sc) {
        if (requireLogin()) return;
        System.out.print("Ten file email: ");
        String name = sc.nextLine().trim();
        show(call(MailProtocol.buildRequest(MailProtocol.CMD_READ, name)));
    }

    private static void doLogout() {
        show(call(MailProtocol.buildRequest(MailProtocol.CMD_LOGOUT)));
        currentAccount = null;
    }

    private static boolean requireLogin() {
        if (currentAccount == null) {
            System.out.println("!!! Ban phai dang nhap truoc.");
            return true;
        }
        return false;
    }

    // ------------------------------------------------------------ UDP

    /** Gui mot yeu cau, cho phan hoi, tu thu lai neu goi tin bi mat. */
    private static MailProtocol.Response call(String request) {
        byte[] out = request.getBytes(StandardCharsets.UTF_8);
        if (out.length > MailProtocol.MAX_DATAGRAM) {
            System.out.println("!!! Noi dung vuot qua " + MailProtocol.MAX_DATAGRAM
                             + " byte - mot goi tin UDP khong chua het.");
            return null;
        }

        for (int attempt = 1; attempt <= RETRIES; attempt++) {
            try {
                socket.send(new DatagramPacket(out, out.length, serverAddress, serverPort));

                byte[] buf = new byte[MailProtocol.MAX_DATAGRAM];
                DatagramPacket in = new DatagramPacket(buf, buf.length);
                socket.receive(in);

                return MailProtocol.parseResponse(
                        new String(in.getData(), 0, in.getLength(), StandardCharsets.UTF_8));

            } catch (SocketTimeoutException e) {
                System.out.println("... khong co phan hoi, thu lai (" + attempt + "/" + RETRIES + ")");
            } catch (MailProtocol.ProtocolException e) {
                System.out.println("!!! Phan hoi sai dinh dang: " + e.getMessage());
                return null;
            } catch (IOException e) {
                System.out.println("!!! Loi mang: " + e.getMessage());
                return null;
            }
        }

        System.out.println("!!! Khong ket noi duoc toi server. Kiem tra server va firewall UDP.");
        return null;
    }

    /** In phan hoi ra man hinh. */
    private static void show(MailProtocol.Response res) {
        if (res == null) return;

        if (res.isOk()) {
            System.out.println("--- " + res.message);
            for (String p : res.payload) System.out.println("    " + p);
        } else {
            System.out.println("!!! [" + res.code + " "
                             + MailProtocol.codeName(res.code) + "] " + res.message);
        }
    }
}
