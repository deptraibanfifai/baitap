package com.library;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

final class AccountCredentials {

    private static final DateTimeFormatter DISPLAY_TIME =
            DateTimeFormatter.ofPattern("HH:mm:ss dd/MM/yyyy")
                    .withZone(ZoneId.systemDefault());

    static final class Credential {
        final String password;
        final String createdAt;
        final boolean legacyHash;

        Credential(String password, String createdAt, boolean legacyHash) {
            this.password = password;
            this.createdAt = createdAt;
            this.legacyHash = legacyHash;
        }
    }

    private AccountCredentials() { }

    static Credential read(Path file, String account) throws IOException {
        String contents = Files.readString(file, StandardCharsets.UTF_8);
        String trimmedContents = contents.trim();
        if (trimmedContents.matches("[0-9a-fA-F]{64}")) {
            String createdAt = Files.readAttributes(file, BasicFileAttributes.class)
                    .creationTime().toInstant().toString();
            return new Credential(trimmedContents, createdAt, true);
        }

        if (contents.startsWith("user: ")) {
            Map<String, String> fields = new HashMap<>();
            for (String line : contents.split("\\R")) {
                int separator = line.indexOf(": ");
                if (separator > 0) {
                    fields.put(line.substring(0, separator),
                            unescape(line.substring(separator + 2)));
                }
            }
            String username = fields.get("user");
            String password = fields.get("matkhau");
            String createdAt = fields.get("tạo lúc");
            if (!account.equals(username) || password == null || createdAt == null) {
                throw new IOException("Thong tin account.cred khong hop le");
            }
            return new Credential(password, createdAt, false);
        }

        Properties properties = new Properties();
        try (InputStream input = Files.newInputStream(file)) {
            properties.load(input);
        }
        String username = properties.getProperty("username");
        String passwordHash = properties.getProperty("password_hash");
        String createdAt = properties.getProperty("created_at");
        if (!account.equals(username) || passwordHash == null || createdAt == null) {
            throw new IOException("Thong tin account.cred khong hop le");
        }
        return new Credential(passwordHash, createdAt, true);
    }

    static void write(Path file, String account, String password,
                      String createdAt, String lastLoginIp, int lastLoginPort)
            throws IOException {
        String contents = "user: " + escape(account) + System.lineSeparator()
                + "matkhau: " + escape(password) + System.lineSeparator()
                + "tạo lúc: " + escape(displayTime(createdAt)) + System.lineSeparator()
                + "IP máy đăng nhập: " + escape(lastLoginIp) + System.lineSeparator()
                + "Cổng đăng nhập: "
                + (lastLoginPort > 0 ? lastLoginPort : "") + System.lineSeparator();
        Files.writeString(file, contents, StandardCharsets.UTF_8);
    }

    static String now() {
        return DISPLAY_TIME.format(Instant.now());
    }

    static String ipFromClientKey(String clientKey) {
        int portSeparator = clientKey.lastIndexOf(':');
        return portSeparator > 0 ? clientKey.substring(0, portSeparator) : clientKey;
    }

    static int portFromClientKey(String clientKey) {
        int portSeparator = clientKey.lastIndexOf(':');
        if (portSeparator < 0 || portSeparator == clientKey.length() - 1) {
            throw new IllegalArgumentException("Dia chi client khong co cong: " + clientKey);
        }
        return Integer.parseInt(clientKey.substring(portSeparator + 1));
    }

    private static String displayTime(String createdAt) {
        try {
            return DISPLAY_TIME.format(Instant.parse(createdAt));
        } catch (DateTimeParseException e) {
            return createdAt;
        }
    }

    private static String escape(String value) {
        return value.replace("\\", "\\\\").replace("\r", "\\r").replace("\n", "\\n");
    }

    private static String unescape(String value) throws IOException {
        StringBuilder result = new StringBuilder(value.length());
        for (int i = 0; i < value.length(); i++) {
            char current = value.charAt(i);
            if (current != '\\') {
                result.append(current);
                continue;
            }
            if (++i >= value.length()) {
                throw new IOException("Thong tin account.cred khong hop le");
            }
            char escaped = value.charAt(i);
            if (escaped == 'n') result.append('\n');
            else if (escaped == 'r') result.append('\r');
            else if (escaped == '\\') result.append('\\');
            else throw new IOException("Thong tin account.cred khong hop le");
        }
        return result.toString();
    }
}
