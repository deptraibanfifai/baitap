package com.library;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Bai 2 - Mail Client co giao dien do hoa, noi giao thuc MAIL/1.0.
 *
 * Chay:  java MailClientGUI [host] [port]
 *
 * Toan bo phan mang nam trong lop MailService ben duoi; giao dien chi goi
 * MailProtocol.buildRequest(...) nen khong ben nao tu y doi dinh dang goi tin.
 */
public class MailClientGUI extends JFrame {

    // ------------------------------------------------------------ bang mau (chu de sang)
    // Dong bo voi MailServerGUI de hai cua so nhin cung mot bo.

    static final Color BG        = new Color(0xF3F5F9);
    static final Color PANEL     = new Color(0xFFFFFF);
    static final Color PANEL_2   = new Color(0xF0F3F8);
    static final Color BORDER    = new Color(0xD9DEE8);
    static final Color TEXT      = new Color(0x1F2937);
    static final Color MUTED     = new Color(0x6B7280);
    static final Color ACCENT    = new Color(0x2563EB);
    static final Color ACCENT_H  = new Color(0x1D4ED8);
    static final Color GREEN     = new Color(0x15803D);
    static final Color RED       = new Color(0xDC2626);

    static final String FAMILY = "Segoe UI";
    static Font font(int style, int size) { return new Font(FAMILY, style, size); }

    // ------------------------------------------------------------ dia chi server
    // KHONG hien tren GUI. De doi dia chi: sua hai gia tri nay, hoac truyen luc chay:
    //     java MailClientGUI <host> <port>      (vi du: java MailClientGUI 192.168.1.10 2346)
    static String serverHost = "127.0.0.1";
    static int    serverPort = MailProtocol.DEFAULT_PORT;

    // ------------------------------------------------------------ trang thai

    private final MailService service = new MailService();
    private String account = null;

    private final CardLayout cards = new CardLayout();
    private final JPanel     root  = new JPanel(cards);

    // man hinh dang nhap
    // hostField / portField duoc giu lai de connect() va hop thoai dang ky doc dia chi,
    // nhung KHONG duoc them vao giao dien.
    private JTextField hostField, portField, accountField;
    private JPasswordField passwordField;
    private JLabel     loginStatus;

    // man hinh chinh
    private DefaultListModel<MailItem> mailModel = new DefaultListModel<>();
    private JList<MailItem>            mailList;
    private JLabel      accountChip, mailboxCount;
    private JLabel      readerSubject, readerMeta;
    private JTextArea   readerBody;
    private JLabel      wireLabel;      // dong hien thi goi tin vua trao doi

    public MailClientGUI() {
        super("Mail UDP - " + MailProtocol.VERSION);

        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);
        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) { shutdown(); }
        });

        root.setBackground(BG);
        root.add(buildLoginScreen(), "login");
        root.add(buildMainScreen(),  "main");

        setContentPane(root);
        setSize(1060, 680);
        setMinimumSize(new Dimension(880, 560));
        setLocationRelativeTo(null);

        cards.show(root, "login");
    }

    // ============================================================ MAN HINH DANG NHAP

    private JPanel buildLoginScreen() {
        JPanel screen = new JPanel(new GridBagLayout());
        screen.setBackground(BG);

        JPanel card = new RoundPanel(PANEL, 18);
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(new EmptyBorder(36, 40, 32, 40));
        card.add(Box.createRigidArea(new Dimension(340, 0)));   // chot chieu rong the

        JLabel logo = new JLabel("✉");            // bieu tuong phong thu
        logo.setFont(font(Font.PLAIN, 44));
        logo.setForeground(ACCENT);
        logo.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel title = new JLabel("Mail Server UDP");
        title.setFont(font(Font.BOLD, 24));
        title.setForeground(TEXT);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JLabel sub = new JLabel("Giao thuc " + MailProtocol.VERSION
                + " tren UDP datagram socket");
        sub.setFont(font(Font.PLAIN, 13));
        sub.setForeground(MUTED);
        sub.setAlignmentX(Component.LEFT_ALIGNMENT);

        // Hai o nay chi giu du lieu (an khoi GUI), khong add vao card.
        hostField    = field(serverHost);
        portField    = field(String.valueOf(serverPort));
        accountField = field("");
        passwordField = passwordField("");

        JPanel passwordRow = wrapPasswordWithEye(passwordField);
        passwordField.addActionListener(e -> doLogin());

        RoundButton loginBtn  = new RoundButton("Dang nhap", ACCENT, ACCENT_H, Color.WHITE);
        RoundButton createBtn = new RoundButton("Tao account moi", PANEL_2, BORDER, TEXT);
        loginBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        createBtn.setAlignmentX(Component.LEFT_ALIGNMENT);
        loginBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        createBtn.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        loginStatus = new JLabel(" ");
        loginStatus.setFont(font(Font.PLAIN, 12));
        loginStatus.setForeground(MUTED);
        loginStatus.setAlignmentX(Component.LEFT_ALIGNMENT);

        loginBtn.addActionListener(e -> doLogin());
        createBtn.addActionListener(e -> doRegister());
        accountField.addActionListener(e -> doLogin());

        card.add(logo);
        card.add(Box.createVerticalStrut(14));
        card.add(title);
        card.add(Box.createVerticalStrut(6));
        card.add(sub);
        card.add(Box.createVerticalStrut(26));
        card.add(caption("Ten account"));
        card.add(Box.createVerticalStrut(6));
        card.add(accountField);
        card.add(Box.createVerticalStrut(16));
        card.add(caption("Mat khau"));
        card.add(Box.createVerticalStrut(6));
        card.add(passwordRow);
        card.add(Box.createVerticalStrut(24));
        card.add(loginBtn);
        card.add(Box.createVerticalStrut(10));
        card.add(createBtn);
        card.add(Box.createVerticalStrut(16));
        card.add(loginStatus);

        screen.add(card);
        return screen;
    }

    // ============================================================ MAN HINH CHINH

    private JPanel buildMainScreen() {
        JPanel screen = new JPanel(new BorderLayout());
        screen.setBackground(BG);

        screen.add(buildTopBar(),    BorderLayout.NORTH);
        screen.add(buildSplit(),     BorderLayout.CENTER);
        screen.add(buildWireStrip(), BorderLayout.SOUTH);

        return screen;
    }

    private JPanel buildTopBar() {
        JPanel bar = new JPanel(new BorderLayout());
        bar.setBackground(PANEL);
        bar.setBorder(new CompoundBorderBottom(BORDER, new EmptyBorder(14, 20, 14, 20)));

        JLabel brand = new JLabel("✉  Mail UDP");
        brand.setFont(font(Font.BOLD, 16));
        brand.setForeground(TEXT);

        accountChip = new JLabel();
        accountChip.setFont(font(Font.PLAIN, 13));
        accountChip.setForeground(MUTED);

        RoundButton logout = new RoundButton("Dang xuat", PANEL_2, BORDER, TEXT);
        logout.setPreferredSize(new Dimension(110, 36));
        logout.addActionListener(e -> doLogout());

        JPanel right = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        right.setOpaque(false);
        right.add(accountChip);
        right.add(logout);

        bar.add(brand, BorderLayout.WEST);
        bar.add(right, BorderLayout.EAST);
        return bar;
    }

    private JComponent buildSplit() {
        JComponent left  = buildMailboxPane();
        JComponent right = buildReaderPane();
        // Khong cho keo divider lam 2 khung bi bop mat noi dung
        left.setMinimumSize(new Dimension(260, 200));
        right.setMinimumSize(new Dimension(300, 200));

        JSplitPane split = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, left, right);
        // Divider 6px, de keo; chi ve 1 duong ke mong o giua
        split.setUI(new javax.swing.plaf.basic.BasicSplitPaneUI() {
            @Override public javax.swing.plaf.basic.BasicSplitPaneDivider createDefaultDivider() {
                return new javax.swing.plaf.basic.BasicSplitPaneDivider(this) {
                    @Override public void paint(Graphics g) {
                        g.setColor(BORDER);
                        g.fillRect(getWidth() / 2, 0, 1, getHeight());
                    }
                };
            }
        });
        split.setBorder(null);
        split.setOpaque(true);
        split.setBackground(BG);
        split.setDividerSize(6);
        split.setContinuousLayout(true);
        split.setDividerLocation(330);
        return split;
    }

    private JPanel buildMailboxPane() {
        JPanel pane = new JPanel(new BorderLayout());
        pane.setBackground(PANEL);

        // --- thanh cong cu
        JPanel tools = new JPanel(new BorderLayout(8, 0));
        tools.setOpaque(false);
        tools.setBorder(new EmptyBorder(16, 16, 10, 16));

        RoundButton compose = new RoundButton("Soan thu", ACCENT, ACCENT_H, Color.WHITE);
        compose.setPreferredSize(new Dimension(10, 40));
        compose.addActionListener(e -> openCompose());

        RoundButton refresh = new RoundButton("↻", PANEL_2, BORDER, TEXT);
        refresh.setPreferredSize(new Dimension(44, 40));
        refresh.setToolTipText("Tai lai hop thu (lenh LIST)");
        refresh.addActionListener(e -> loadMailbox(false));

        tools.add(compose, BorderLayout.CENTER);
        tools.add(refresh, BorderLayout.EAST);

        mailboxCount = new JLabel("HOP THU");
        mailboxCount.setFont(font(Font.BOLD, 11));
        mailboxCount.setForeground(MUTED);
        mailboxCount.setBorder(new EmptyBorder(4, 18, 8, 18));

        // --- danh sach thu
        mailList = new JList<>(mailModel);
        mailList.setBackground(PANEL);
        mailList.setFixedCellHeight(64);
        mailList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        mailList.setCellRenderer(new MailRenderer());
        mailList.addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) openSelected();
        });

        JScrollPane scroll = new JScrollPane(mailList);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(PANEL);
        scroll.getVerticalScrollBar().setUnitIncrement(16);
        styleScrollBar(scroll.getVerticalScrollBar());

        JPanel north = new JPanel(new BorderLayout());
        north.setOpaque(false);
        north.add(tools,        BorderLayout.NORTH);
        north.add(mailboxCount, BorderLayout.SOUTH);

        pane.add(north,  BorderLayout.NORTH);
        pane.add(scroll, BorderLayout.CENTER);
        return pane;
    }

    private JPanel buildReaderPane() {
        JPanel pane = new JPanel(new BorderLayout());
        pane.setBackground(BG);

        JPanel header = new JPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setOpaque(false);
        header.setBorder(new CompoundBorderBottom(BORDER, new EmptyBorder(22, 26, 18, 26)));

        readerSubject = new JLabel("Chon mot email de doc");
        readerSubject.setFont(font(Font.BOLD, 19));
        readerSubject.setForeground(TEXT);
        readerSubject.setAlignmentX(Component.LEFT_ALIGNMENT);

        readerMeta = new JLabel("Danh sach ben trai lay tu lenh LOGIN / LIST cua server");
        readerMeta.setFont(font(Font.PLAIN, 12));
        readerMeta.setForeground(MUTED);
        readerMeta.setAlignmentX(Component.LEFT_ALIGNMENT);

        header.add(readerSubject);
        header.add(Box.createVerticalStrut(7));
        header.add(readerMeta);

        readerBody = new JTextArea();
        readerBody.setEditable(false);
        readerBody.setLineWrap(true);
        readerBody.setWrapStyleWord(true);
        readerBody.setBackground(BG);
        readerBody.setForeground(new Color(0x374151));   // chu toi tren nen sang
        readerBody.setCaretColor(TEXT);
        readerBody.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 13));
        readerBody.setBorder(new EmptyBorder(22, 26, 26, 26));

        JScrollPane scroll = new JScrollPane(readerBody);
        scroll.setBorder(null);
        scroll.getViewport().setBackground(BG);
        styleScrollBar(scroll.getVerticalScrollBar());

        pane.add(header, BorderLayout.NORTH);
        pane.add(scroll, BorderLayout.CENTER);
        return pane;
    }

    /** Dai hien thi goi tin vua gui / nhan - de minh hoa giao thuc khi demo. */
    private JPanel buildWireStrip() {
        JPanel strip = new JPanel(new BorderLayout());
        strip.setBackground(PANEL_2);
        strip.setBorder(new CompoundBorderTop(BORDER, new EmptyBorder(8, 18, 8, 18)));

        wireLabel = new JLabel("San sang");
        wireLabel.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
        wireLabel.setForeground(MUTED);

        strip.add(wireLabel, BorderLayout.WEST);
        return strip;
    }

    // ============================================================ HANH DONG

    private void doRegister() {
        openRegisterDialog();
    }

    private void doLogin() {
        String acc  = accountField.getText().trim();
        String pass = new String(passwordField.getPassword());
        if (acc.isEmpty())  { loginInfo("Nhap ten account truoc da.", RED); return; }
        if (pass.isEmpty()) { loginInfo("Nhap mat khau truoc da.", RED); return; }
        if (!MailProtocol.isValidPassword(pass)) {
            loginInfo("Mat khau dai it nhat 4 ky tu.", RED); return;
        }
        if (!connect()) return;

        loginInfo("Dang gui LOGIN...", MUTED);
        send(MailProtocol.buildRequest(MailProtocol.CMD_LOGIN, acc, pass), res -> {
            if (res == null)     { loginInfo("Khong ket noi duoc toi server.", RED); return; }
            if (!res.isOk())     { loginInfo(res.message, RED); return; }

            account = acc;
            accountChip.setText("Dang dang nhap:  " + acc);
            fillMailbox(res.payload);

            // Dang ky nhan thong bao co thu moi tu server -> tu dong refresh inbox
            service.setNotifyCallback(() -> {
                if (account != null) loadMailbox(true);
            });

            cards.show(root, "main");
        });
    }

    private void doLogout() {
        service.setNotifyCallback(null);
        send(MailProtocol.buildRequest(MailProtocol.CMD_LOGOUT), res -> {
            account = null;
            mailModel.clear();
            clearReader();
            passwordField.setText("");      // khong giu mat khau sau khi dang xuat
            loginInfo("Da dang xuat.", MUTED);
            cards.show(root, "login");
        });
    }

    /** Goi lenh LIST de lay lai danh sach file trong hop thu. */
    private void loadMailbox(boolean silent) {
        send(MailProtocol.buildRequest(MailProtocol.CMD_LIST), res -> {
            if (res != null && res.isOk()) fillMailbox(res.payload);
            else if (!silent && res != null) toast(res.message);
        });
    }

    private void fillMailbox(String[] fileNames) {
        mailModel.clear();
        for (String name : fileNames) mailModel.addElement(new MailItem(name));
        mailboxCount.setText("HOP THU  ·  " + fileNames.length + " thu");
        prefetchHeaders();
    }

    /**
     * Doc truoc tieu de cua tung file (lenh READ) de danh sach hien thi
     * "Tu ai - tieu de" thay vi chi ten file. Chay nen, khong chan giao dien.
     */
    private void prefetchHeaders() {
        final List<MailItem> items = new ArrayList<>();
        for (int i = 0; i < mailModel.size() && i < 60; i++) items.add(mailModel.get(i));

        new SwingWorker<Void, MailItem>() {
            @Override protected Void doInBackground() {
                for (MailItem item : items) {
                    if (item.loaded) continue;
                    MailProtocol.Response res = service.callQuiet(
                            MailProtocol.buildRequest(MailProtocol.CMD_READ, item.file));
                    if (res != null && res.isOk()) {
                        item.applyContent(res.data(0));
                        publish(item);
                    }
                }
                return null;
            }
            @Override protected void process(List<MailItem> done) { mailList.repaint(); }
        }.execute();
    }

    private void openSelected() {
        MailItem item = mailList.getSelectedValue();
        if (item == null) return;

        if (item.loaded) { showMail(item); return; }

        send(MailProtocol.buildRequest(MailProtocol.CMD_READ, item.file), res -> {
            if (res != null && res.isOk()) {
                item.applyContent(res.data(0));
                mailList.repaint();
                showMail(item);
            } else if (res != null) {
                toast(res.message);
            }
        });
    }

    private void showMail(MailItem item) {
        readerSubject.setText(item.title());
        readerMeta.setText(item.metaLine());
        readerBody.setText(item.body);
        readerBody.setCaretPosition(0);
    }

    private void clearReader() {
        readerSubject.setText("Chon mot email de doc");
        readerMeta.setText(" ");
        readerBody.setText("");
    }

    // ------------------------------------------------------------ soan thu

    private void openCompose() {
        JDialog dialog = new JDialog(this, "Soan thu", true);
        dialog.getContentPane().setBackground(PANEL);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(PANEL);
        body.setBorder(new EmptyBorder(24, 26, 22, 26));

        JLabel title = new JLabel("Thu moi");
        title.setFont(font(Font.BOLD, 18));
        title.setForeground(TEXT);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField to      = field("");
        JTextField subject = field("");

        JTextArea content = new JTextArea(10, 30);
        content.setLineWrap(true);
        content.setWrapStyleWord(true);
        content.setBackground(PANEL_2);
        content.setForeground(TEXT);
        content.setCaretColor(TEXT);
        content.setFont(font(Font.PLAIN, 13));
        content.setBorder(new EmptyBorder(12, 12, 12, 12));

        JScrollPane contentScroll = new JScrollPane(content);
        contentScroll.setBorder(new RoundLineBorder(BORDER, 10));
        contentScroll.getViewport().setBackground(PANEL_2);
        contentScroll.setAlignmentX(Component.LEFT_ALIGNMENT);
        styleScrollBar(contentScroll.getVerticalScrollBar());

        JLabel status = new JLabel(" ");
        status.setFont(font(Font.PLAIN, 12));
        status.setForeground(MUTED);
        status.setAlignmentX(Component.LEFT_ALIGNMENT);

        RoundButton sendBtn   = new RoundButton("Gui", ACCENT, ACCENT_H, Color.WHITE);
        RoundButton cancelBtn = new RoundButton("Huy", PANEL_2, BORDER, TEXT);
        sendBtn.setPreferredSize(new Dimension(100, 40));
        cancelBtn.setPreferredSize(new Dimension(100, 40));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actions.setOpaque(false);
        actions.setAlignmentX(Component.LEFT_ALIGNMENT);
        actions.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        actions.add(cancelBtn);
        actions.add(sendBtn);

        cancelBtn.addActionListener(e -> dialog.dispose());
        sendBtn.addActionListener(e -> {
            String receiver = to.getText().trim();
            if (receiver.isEmpty()) {
                status.setForeground(RED);
                status.setText("Chua nhap nguoi nhan.");
                return;
            }
            String request = MailProtocol.buildRequest(MailProtocol.CMD_SEND,
                    receiver, subject.getText().trim(), content.getText());

            if (MailProtocol.byteLength(request) > MailProtocol.MAX_DATAGRAM) {
                status.setForeground(RED);
                status.setText("Noi dung qua dai cho mot goi tin UDP ("
                        + MailProtocol.MAX_DATAGRAM + " byte).");
                return;
            }

            status.setForeground(MUTED);
            status.setText("Dang gui...");
            send(request, res -> {
                if (res == null)     { status.setForeground(RED); status.setText("Mat ket noi."); }
                else if (res.isOk()) { dialog.dispose(); toast("Da gui thu toi " + receiver); }
                else                 { status.setForeground(RED); status.setText(res.message); }
            });
        });

        body.add(title);
        body.add(Box.createVerticalStrut(20));
        body.add(caption("Gui toi account"));
        body.add(Box.createVerticalStrut(6));
        body.add(to);
        body.add(Box.createVerticalStrut(14));
        body.add(caption("Tieu de"));
        body.add(Box.createVerticalStrut(6));
        body.add(subject);
        body.add(Box.createVerticalStrut(14));
        body.add(caption("Noi dung"));
        body.add(Box.createVerticalStrut(6));
        body.add(contentScroll);
        body.add(Box.createVerticalStrut(16));
        body.add(actions);
        body.add(Box.createVerticalStrut(10));
        body.add(status);

        dialog.setContentPane(body);
        dialog.setSize(540, 620);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    /**
     * Mo hop thoai dang ky tai khoan: nhap account, mat khau, xac nhan mat khau,
     * kiem tra dieu kien hop le, gui REGISTER len server. Thanh cong tu dong dien
     * thong tin len man hinh dang nhap.
     */
    private void openRegisterDialog() {
        JDialog dialog = new JDialog(this, "Dang ky tai khoan", true);
        dialog.getContentPane().setBackground(PANEL);

        JPanel body = new JPanel();
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBackground(PANEL);
        body.setBorder(new EmptyBorder(24, 26, 22, 26));

        JLabel title = new JLabel("Tao account moi");
        title.setFont(font(Font.BOLD, 18));
        title.setForeground(TEXT);
        title.setAlignmentX(Component.LEFT_ALIGNMENT);

        JTextField accField       = field("");
        JPasswordField pass1Field = passwordField("");
        JPasswordField pass2Field = passwordField("");
        JPanel pass1Row = wrapPasswordWithEye(pass1Field);
        JPanel pass2Row = wrapPasswordWithEye(pass2Field);

        JLabel status = new JLabel(" ");
        status.setFont(font(Font.PLAIN, 12));
        status.setForeground(MUTED);
        status.setAlignmentX(Component.LEFT_ALIGNMENT);

        RoundButton createBtn = new RoundButton("Tao tai khoan", ACCENT, ACCENT_H, Color.WHITE);
        RoundButton cancelBtn = new RoundButton("Huy", PANEL_2, BORDER, TEXT);
        createBtn.setPreferredSize(new Dimension(140, 40));
        cancelBtn.setPreferredSize(new Dimension(100, 40));

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        actions.setOpaque(false);
        actions.setAlignmentX(Component.LEFT_ALIGNMENT);
        actions.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        actions.add(cancelBtn);
        actions.add(createBtn);

        cancelBtn.addActionListener(e -> dialog.dispose());

        createBtn.addActionListener(e -> {
            String acc   = accField.getText().trim();
            String pass1 = new String(pass1Field.getPassword());
            String pass2 = new String(pass2Field.getPassword());

            if (acc.isEmpty()) {
                status.setForeground(RED);
                status.setText("Nhap ten account.");
                return;
            }
            if (!MailProtocol.isValidAccount(acc)) {
                status.setForeground(RED);
                status.setText("Ten account chi chua chu, so, . _ - va toi da 32 ky tu.");
                return;
            }
            if (pass1.isEmpty()) {
                status.setForeground(RED);
                status.setText("Nhap mat khau.");
                return;
            }
            if (!MailProtocol.isValidPassword(pass1)) {
                status.setForeground(RED);
                status.setText("Mat khau dai it nhat 4 ky tu va toi da 32 ky tu.");
                return;
            }
            if (!pass1.equals(pass2)) {
                status.setForeground(RED);
                status.setText("Hai mat khau nhap vao khong khop.");
                return;
            }

            // Luon mo lai socket theo dia chi server hien tai
            // (neu chi mo khi chua co, doi may chu roi bam dang ky se gui nham may cu).
            try {
                int port = Integer.parseInt(portField.getText().trim());
                service.open(hostField.getText().trim(), port);
            } catch (NumberFormatException ex) {
                status.setForeground(RED);
                status.setText("Cong ket noi toi server khong hop le.");
                return;
            } catch (IOException ex) {
                status.setForeground(RED);
                status.setText("Khong ket noi duoc may chu: " + ex.getMessage());
                return;
            }

            status.setForeground(MUTED);
            status.setText("Dang gui yeu cau dang ky...");

            String request = MailProtocol.buildRequest(
                    MailProtocol.CMD_REGISTER, acc, pass1);
            send(request, res -> {
                if (res == null) {
                    status.setForeground(RED);
                    status.setText("Khong nhan duoc phan hoi tu server.");
                } else if (res.isOk()) {
                    // Thanh cong: tu dong dien vao 2 o tren man hinh dang nhap
                    accountField.setText(acc);
                    passwordField.setText(pass1);
                    loginInfo("Da tao account. Bam Dang nhap de vao.", GREEN);
                    dialog.dispose();
                } else {
                    status.setForeground(RED);
                    status.setText(res.message);
                }
            });
        });

        body.add(title);
        body.add(Box.createVerticalStrut(20));
        body.add(caption("Ten account"));
        body.add(Box.createVerticalStrut(6));
        body.add(accField);
        body.add(Box.createVerticalStrut(14));
        body.add(caption("Mat khau"));
        body.add(Box.createVerticalStrut(6));
        body.add(pass1Row);
        body.add(Box.createVerticalStrut(14));
        body.add(caption("Xac nhan lai mat khau"));
        body.add(Box.createVerticalStrut(6));
        body.add(pass2Row);
        body.add(Box.createVerticalStrut(20));
        body.add(actions);
        body.add(Box.createVerticalStrut(10));
        body.add(status);

        dialog.setContentPane(body);
        dialog.setSize(520, 580);
        dialog.setLocationRelativeTo(this);
        dialog.setVisible(true);
    }

    // ============================================================ MANG

    /** Mo socket toi server (dia chi lay tu hostField / portField an, khoi tao tu serverHost / serverPort). */
    private boolean connect() {
        try {
            int port = Integer.parseInt(portField.getText().trim());
            service.open(hostField.getText().trim(), port);
            return true;
        } catch (NumberFormatException e) {
            loginInfo("Cong khong hop le.", RED);
        } catch (IOException e) {
            loginInfo("Khong mo duoc socket: " + e.getMessage(), RED);
        }
        return false;
    }

    /** Gui yeu cau o luong nen, tra ket qua ve EDT. */
    private void send(String request, java.util.function.Consumer<MailProtocol.Response> then) {
        wire("-> " + preview(request));

        new SwingWorker<MailProtocol.Response, Void>() {
            @Override protected MailProtocol.Response doInBackground() {
                return service.callQuiet(request);
            }
            @Override protected void done() {
                MailProtocol.Response res = null;
                try { res = get(); } catch (Exception ignored) { }

                if (res == null) wire("<- (khong co phan hoi)");
                else wire("<- " + res.code + " " + MailProtocol.codeName(res.code)
                        + "  " + res.message);

                then.accept(res);
            }
        }.execute();
    }

    private void shutdown() {
        if (account != null) service.callQuiet(MailProtocol.buildRequest(MailProtocol.CMD_LOGOUT));
        service.close();
        dispose();
        System.exit(0);
    }

    // ============================================================ TIEN ICH GIAO DIEN

    private void loginInfo(String text, Color color) {
        loginStatus.setForeground(color);
        loginStatus.setText(text);
    }

    private void wire(String text) {
        if (wireLabel != null) wireLabel.setText(text);
    }

    private void toast(String text) {
        wire("   " + text);
        Toolkit.getDefaultToolkit().beep();
    }

    private static String preview(String request) {
        String s = request.replace("\n", "\\n");
        return s.length() > 110 ? s.substring(0, 110) + "..." : s;
    }

    private static JLabel caption(String text) {
        JLabel l = new JLabel(text.toUpperCase());
        l.setFont(font(Font.BOLD, 11));
        l.setForeground(MUTED);
        l.setAlignmentX(Component.LEFT_ALIGNMENT);
        return l;
    }

    private static JTextField field(String value) {
        JTextField f = new JTextField(value);
        f.setFont(font(Font.PLAIN, 14));
        f.setForeground(TEXT);
        f.setCaretColor(TEXT);
        f.setBackground(PANEL_2);
        f.setBorder(new CompoundBorderPad(new RoundLineBorder(BORDER, 10), 12));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        f.setPreferredSize(new Dimension(10, 44));
        return f;
    }

    /** Tao mot o nhap mat khau (JPasswordField) cung phong cach voi field(). */
    private static JPasswordField passwordField(String value) {
        JPasswordField f = new JPasswordField(value);
        f.setFont(font(Font.PLAIN, 14));
        f.setForeground(TEXT);
        f.setCaretColor(TEXT);
        f.setBackground(PANEL_2);
        f.setBorder(new CompoundBorderPad(new RoundLineBorder(BORDER, 10), 12));
        f.setAlignmentX(Component.LEFT_ALIGNMENT);
        f.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));
        f.setPreferredSize(new Dimension(10, 44));
        f.setEchoChar('●');   // dau tron den an mat khau
        return f;
    }

    /**
     * Boc mot JPasswordField vao JPanel kem ben phai la mot nut "mat" de bam
     * cho phep hien thi noi dung mat khau (echo char = 0) hoac an lai.
     * Khung bo goc tron + nen duoc ve boi borderWrap; o nhap ben trong trong suot
     * de khong de goc vuong chen len vien bo tron.
     */
    private static JPanel wrapPasswordWithEye(JPasswordField passField) {
        JPanel wrap = new JPanel(new BorderLayout(0, 0));
        wrap.setOpaque(false);
        wrap.setAlignmentX(Component.LEFT_ALIGNMENT);
        wrap.setMaximumSize(new Dimension(Integer.MAX_VALUE, 46));

        passField.setBorder(new EmptyBorder(0, 12, 0, 6));
        passField.setOpaque(false);

        JButton eye = new JButton("👁");
        eye.setFont(font(Font.PLAIN, 16));
        eye.setForeground(MUTED);
        eye.setBorderPainted(false);
        eye.setFocusPainted(false);
        eye.setContentAreaFilled(false);
        eye.setCursor(new Cursor(Cursor.HAND_CURSOR));
        eye.setPreferredSize(new Dimension(46, 44));
        eye.setToolTipText("Hien / an mat khau");

        final char defaultEcho = passField.getEchoChar();
        final boolean[] show = {false};
        eye.addActionListener(ev -> {
            show[0] = !show[0];
            if (show[0]) {
                passField.setEchoChar((char) 0);
                eye.setText("🙈");
            } else {
                passField.setEchoChar(defaultEcho);
                eye.setText("👁");
            }
        });

        JPanel borderWrap = new JPanel(new BorderLayout()) {
            @Override protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                        RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PANEL_2);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        borderWrap.setOpaque(false);
        // dem 1px de vien bo tron khong bi con (o nhap, nut mat) de len
        borderWrap.setBorder(new CompoundBorderPad(new RoundLineBorder(BORDER, 10), 1));
        borderWrap.add(passField, BorderLayout.CENTER);
        borderWrap.add(eye,       BorderLayout.EAST);

        wrap.add(borderWrap, BorderLayout.CENTER);
        return wrap;
    }

    private static void styleScrollBar(JScrollBar bar) {
        bar.setUnitIncrement(16);
        bar.setBackground(BG);
        bar.setUI(new javax.swing.plaf.basic.BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                thumbColor = new Color(0xC3CAD8);
                trackColor = BG;
            }
            @Override protected JButton createDecreaseButton(int o) { return zeroButton(); }
            @Override protected JButton createIncreaseButton(int o) { return zeroButton(); }
            private JButton zeroButton() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                return b;
            }
        });
        bar.setPreferredSize(new Dimension(8, 0));
    }

    // ============================================================ MAIN

    public static void main(String[] args) {
        // Tham so tuy chon: <host> <port>  (ghi de gia tri mac dinh serverHost / serverPort)
        if (args.length >= 1 && !args[0].trim().isEmpty()) serverHost = args[0].trim();
        if (args.length >= 2) {
            try { serverPort = Integer.parseInt(args[1].trim()); }
            catch (NumberFormatException ignored) { }
        }

        System.setProperty("awt.useSystemAAFontSettings", "on");
        System.setProperty("swing.aatext", "true");

        SwingUtilities.invokeLater(() -> {
            ToolTipManager.sharedInstance().setInitialDelay(300);
            UIManager.put("ToolTip.background", PANEL_2);
            UIManager.put("ToolTip.foreground", TEXT);
            new MailClientGUI().setVisible(true);
        });
    }

    // ============================================================ MO HINH DU LIEU

    /** Mot buc thu trong hop thu: ten file + phan header doc duoc tu noi dung. */
    static class MailItem {
        final String file;
        String from = "", subject = "", date = "", content = "", body = "";
        volatile boolean loaded = false;

        MailItem(String file) { this.file = file; }

        /** Tach cac dong From/Subject/Date o dau file, phan con lai la noi dung thu. */
        void applyContent(String raw) {
            content = raw;

            String[] lines = raw.split("\\r?\\n", -1);
            int headerEnd = -1;
            for (int i = 0; i < lines.length; i++) {
                String line = lines[i];
                if (line.isEmpty()) { headerEnd = i; break; }    // dong trong = het header
                if (line.startsWith("From: "))         from    = line.substring(6).trim();
                else if (line.startsWith("Subject: ")) subject = line.substring(9).trim();
                else if (line.startsWith("Date: "))    date    = line.substring(6).trim();
            }

            // File khong co header (vi du new_email.txt) thi hien thi nguyen van
            if (headerEnd < 0 || (from.isEmpty() && subject.isEmpty() && date.isEmpty())) {
                body = raw;
            } else {
                body = String.join("\n",
                        java.util.Arrays.copyOfRange(lines, headerEnd + 1, lines.length));
            }
            loaded = true;   // dat cuoi cung: luong khac thay loaded=true thi du lieu da san sang
        }

        String title() {
            if (!subject.isEmpty()) return subject;
            if (MailProtocol.WELCOME_FILE.equals(file)) return "Thu chao mung";
            return file;
        }

        String metaLine() {
            StringBuilder sb = new StringBuilder();
            if (!from.isEmpty()) sb.append("Tu ").append(from);
            if (!date.isEmpty()) sb.append(sb.length() > 0 ? "  ·  " : "").append(date);
            if (sb.length() == 0) sb.append(file);
            else sb.append("  ·  ").append(file);
            return sb.toString();
        }
    }

    /** Ve moi dong trong danh sach thu: tieu de dam + dong phu mo. */
    static class MailRenderer extends JPanel implements ListCellRenderer<MailItem> {
        private final JLabel line1 = new JLabel();
        private final JLabel line2 = new JLabel();
        private boolean selected;

        MailRenderer() {
            setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
            setBorder(new EmptyBorder(12, 18, 12, 14));
            setOpaque(false);
            line1.setFont(font(Font.BOLD, 13));
            line2.setFont(font(Font.PLAIN, 11));
            add(line1);
            add(Box.createVerticalStrut(5));
            add(line2);
        }

        @Override public Component getListCellRendererComponent(
                JList<? extends MailItem> list, MailItem item, int index,
                boolean isSelected, boolean hasFocus) {

            selected = isSelected;
            line1.setText(item.title());
            line1.setForeground(isSelected ? Color.WHITE : TEXT);

            String meta = item.from.isEmpty() ? item.file : "Tu " + item.from;
            if (!item.date.isEmpty()) meta += "   " + item.date;
            line2.setText(meta);
            line2.setForeground(isSelected ? new Color(0xE3ECFF) : MUTED);
            return this;
        }

        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            if (selected) {
                g2.setColor(ACCENT);
                g2.fillRoundRect(8, 3, getWidth() - 16, getHeight() - 6, 10, 10);
            } else {
                g2.setColor(BORDER);
                g2.fillRect(18, getHeight() - 1, getWidth() - 32, 1);
            }
            g2.dispose();
            super.paintComponent(g);
        }
    }

    // ============================================================ THANH PHAN TU VE

    /** Panel nen bo goc tron. */
    static class RoundPanel extends JPanel {
        private final Color color; private final int radius;
        RoundPanel(Color color, int radius) {
            this.color = color; this.radius = radius;
            setOpaque(false);
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Nut bo goc tron, doi mau khi di chuot qua, xam di khi bi vo hieu hoa. */
    static class RoundButton extends JButton {
        private final Color base, hover;
        RoundButton(String text, Color base, Color hover, Color fg) {
            super(text);
            this.base = base; this.hover = hover;
            setForeground(fg);
            setFont(font(Font.BOLD, 13));
            setContentAreaFilled(false);
            setFocusPainted(false);
            setBorderPainted(false);
            setBorder(new EmptyBorder(10, 16, 10, 16));
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }
        @Override protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            Color c = !isEnabled() ? BORDER
                    : getModel().isRollover() ? hover : base;
            g2.setColor(c);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** Vien bo goc tron. */
    static class RoundLineBorder extends AbstractBorder {
        private final Color color; private final int radius;
        RoundLineBorder(Color color, int radius) { this.color = color; this.radius = radius; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                    RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.drawRoundRect(x, y, w - 1, h - 1, radius, radius);
            g2.dispose();
        }
        @Override public Insets getBorderInsets(Component c) { return new Insets(1, 1, 1, 1); }
    }

    /** Vien tron + dem trong, dung cho o nhap lieu. */
    static class CompoundBorderPad extends AbstractBorder {
        private final AbstractBorder outer; private final int pad;
        CompoundBorderPad(AbstractBorder outer, int pad) { this.outer = outer; this.pad = pad; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            outer.paintBorder(c, g, x, y, w, h);
        }
        @Override public Insets getBorderInsets(Component c) {
            return new Insets(pad, pad, pad, pad);
        }
    }

    /** Duong ke 1px o canh duoi + dem trong. */
    static class CompoundBorderBottom extends AbstractBorder {
        private final Color line; private final EmptyBorder pad;
        CompoundBorderBottom(Color line, EmptyBorder pad) { this.line = line; this.pad = pad; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            g.setColor(line);
            g.fillRect(x, y + h - 1, w, 1);
        }
        @Override public Insets getBorderInsets(Component c) { return pad.getBorderInsets(c); }
    }

    /** Duong ke 1px o canh tren + dem trong. */
    static class CompoundBorderTop extends AbstractBorder {
        private final Color line; private final EmptyBorder pad;
        CompoundBorderTop(Color line, EmptyBorder pad) { this.line = line; this.pad = pad; }
        @Override public void paintBorder(Component c, Graphics g, int x, int y, int w, int h) {
            g.setColor(line);
            g.fillRect(x, y, w, 1);
        }
        @Override public Insets getBorderInsets(Component c) { return pad.getBorderInsets(c); }
    }

    // ============================================================ TANG MANG

    /**
     * Boc DatagramSocket:
     *  - Mot listener thread lien tuc doc goi tin tu socket
     *  - Goi tin Response (ma so) dua vao bien doi cho callQuiet lay ra
     *  - Goi tin NOTIFY (server push) goi callback de giao dien refresh inbox
     */
    static class MailService {
        private static final int TIMEOUT_MS = 2500;
        private static final int RETRIES    = 2;

        private DatagramSocket socket;
        private InetAddress    address;
        private int            port;

        private Thread             listenerThread;
        private volatile boolean  running = false;

        private final Object              respLock = new Object();
        private MailProtocol.Response pendingResponse = null;

        private volatile Runnable notifyCallback = null;

        /** Dang ky ham se duoc goi (tren EDT) khi server thong bao co thu moi. */
        void setNotifyCallback(Runnable r) { this.notifyCallback = r; }

        /** Kiem tra socket da duoc mo va chua dong. */
        boolean isOpened() {
            return socket != null && !socket.isClosed();
        }

        synchronized void open(String host, int port) throws IOException {
            close();
            this.address = InetAddress.getByName(host);
            this.port    = port;
            this.socket  = new DatagramSocket();
            this.socket.setSoTimeout(0); // listener thread tu cho timeout

            this.running = true;
            this.listenerThread = new Thread(this::listenerLoop, "MailClient-Listener");
            this.listenerThread.setDaemon(true);
            this.listenerThread.start();
        }

        /** Vong lap lien tuc nhan goi tin tu socket. */
        private void listenerLoop() {
            byte[] buf = new byte[MailProtocol.MAX_DATAGRAM];
            while (running && socket != null && !socket.isClosed()) {
                try {
                    DatagramPacket in = new DatagramPacket(buf, buf.length);
                    socket.receive(in);
                    String raw = new String(in.getData(), 0, in.getLength(), StandardCharsets.UTF_8);

                    if (MailProtocol.isLikelyResponse(raw)) {
                        // Phan hoi cho mot lenh da gui -> goi callQuiet dang cho
                        MailProtocol.Response res = MailProtocol.parseResponse(raw);
                        synchronized (respLock) {
                            pendingResponse = res;
                            respLock.notifyAll();
                        }
                    } else {
                        // Goi tin khong phai phan hoi -> thuong la thong bao tu server
                        try {
                            MailProtocol.Request req = MailProtocol.parseRequest(raw);
                            if (MailProtocol.CMD_NOTIFY.equals(req.command)
                                    && "NEW_MAIL".equals(req.arg(0))) {
                                // Co thu moi -> bao giao dien tai lai hop thu
                                Runnable cb = notifyCallback;
                                if (cb != null) {
                                    SwingUtilities.invokeLater(cb);
                                }
                            }
                        } catch (MailProtocol.ProtocolException ignored) { }
                    }
                } catch (SocketTimeoutException e) {
                    // khong xay ra vi setSoTimeout(0)
                } catch (IOException | MailProtocol.ProtocolException e) {
                    if (!running) break;
                }
            }
        }

        /** Gui yeu cau va cho phan hoi; tra ve null neu khong nhan duoc gi. */
        synchronized MailProtocol.Response callQuiet(String request) {
            if (socket == null || socket.isClosed()) return null;

            byte[] out = request.getBytes(StandardCharsets.UTF_8);
            if (out.length > MailProtocol.MAX_DATAGRAM) return null;

            for (int i = 0; i < RETRIES; i++) {
                synchronized (respLock) {
                    pendingResponse = null;
                }
                try {
                    socket.send(new DatagramPacket(out, out.length, address, port));
                } catch (IOException e) {
                    return null;
                }

                // Cho den khi co response hoac het timeout
                long deadline = System.currentTimeMillis() + TIMEOUT_MS;
                synchronized (respLock) {
                    while (pendingResponse == null) {
                        long remain = deadline - System.currentTimeMillis();
                        if (remain <= 0) break;
                        try { respLock.wait(remain); }
                        catch (InterruptedException ie) {
                            Thread.currentThread().interrupt();
                            return null;
                        }
                    }
                    if (pendingResponse != null) {
                        MailProtocol.Response r = pendingResponse;
                        pendingResponse = null;
                        return r;
                    }
                }
                // het thoi gian -> retry
            }
            return null;
        }

        synchronized void close() {
            running = false;
            if (listenerThread != null) {
                listenerThread.interrupt();
                listenerThread = null;
            }
            if (socket != null && !socket.isClosed()) socket.close();
            socket = null;
            notifyCallback = null;
        }
    }
}