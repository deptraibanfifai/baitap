package com.library;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * MAIL/1.0 - Giao thuc tang ung dung chay tren UDP.
 *
 * Lop nay la "hop dong" chung giua server va client: ca hai ben cung dung
 * encode/decode o day nen khong ben nao tu y doi dinh dang duoc.
 *
 * ---------------------------------------------------------------------------
 * DINH DANG GOI TIN  (text UTF-8, cac truong phan cach bang ky tu '|')
 * ---------------------------------------------------------------------------
 *   Request :  MAIL/1.0|<COMMAND>|<arg1>|<arg2>|...
 *   Response:  MAIL/1.0|<CODE>|<message>|<payload1>|<payload2>|...
 *
 * ---------------------------------------------------------------------------
 * CAC LENH
 * ---------------------------------------------------------------------------
 *   REGISTER|<account>|<mat_khau>                   -> 200 | 400 | 409
 *   LOGIN|<account>|<mat_khau>                      -> 200 (payload = ten cac file) | 401 | 404
 *   SEND|<nguoi_nhan>|<tieu_de>|<noi_dung>          -> 200 (payload = ten file) | 401 | 404
 *   LIST                                            -> 200 (payload = ten cac file) | 401
 *   READ|<ten_file>                                 -> 200 (payload[0] = noi dung) | 401 | 404
 *   LOGOUT                                          -> 200
 *   PING                                            -> 200   (kiem tra server song)
 *   NOTIFY|<NEW_MAIL>...                            -> (push thong bao tu server)
 *
 * ---------------------------------------------------------------------------
 * MA TRANG THAI
 * ---------------------------------------------------------------------------
 *   200 OK            - thanh cong
 *   400 BAD_REQUEST   - sai cu phap / tham so khong hop le
 *   401 UNAUTHORIZED  - chua dang nhap
 *   404 NOT_FOUND     - khong tim thay account hoac file
 *   409 CONFLICT      - account da ton tai
 *   500 SERVER_ERROR  - loi phia server
 *
 * ---------------------------------------------------------------------------
 * ESCAPE
 * ---------------------------------------------------------------------------
 * Vi '|' la ky tu phan cach nen moi truong deu duoc escape truoc khi ghep:
 *      \   ->  \\
 *      |   ->  \p
 *      \n  ->  \n
 *      \r  ->  \r
 * Nho vay noi dung email co the chua dau '|' va xuong dong tu do ma khong
 * lam hong goi tin.
 */
public final class MailProtocol {

    private MailProtocol() { }   // lop tien ich, khong cho khoi tao

    // ------------------------------------------------------------ hang so

    public static final String VERSION       = "MAIL/1.0";
    public static final int    DEFAULT_PORT  = 2346;
    public static final int    MAX_DATAGRAM  = 8192;   // kich thuoc buffer toi da

    // Lenh
    public static final String CMD_REGISTER = "REGISTER";
    public static final String CMD_LOGIN    = "LOGIN";
    public static final String CMD_SEND     = "SEND";
    public static final String CMD_LIST     = "LIST";
    public static final String CMD_READ     = "READ";
    public static final String CMD_LOGOUT   = "LOGOUT";
    public static final String CMD_PING     = "PING";
    public static final String CMD_NOTIFY   = "NOTIFY";

    // Ma trang thai
    public static final int OK           = 200;
    public static final int BAD_REQUEST  = 400;
    public static final int UNAUTHORIZED = 401;
    public static final int NOT_FOUND    = 404;
    public static final int CONFLICT     = 409;
    public static final int SERVER_ERROR = 500;

    /** Ten file loi chao tao kem khi dang ky account (theo yeu cau de bai). */
    public static final String WELCOME_FILE = "new_email.txt";

    public static final String WELCOME_TEXT =
            "Thank you for using this service. "
          + "We hope that you will feel comfortable with it.";

    // ------------------------------------------------------------ kieu du lieu

    /** Loi khi goi tin khong dung dinh dang MAIL/1.0. */
    public static class ProtocolException extends Exception {
        public ProtocolException(String message) { super(message); }
    }

    /** Mot yeu cau da duoc phan tich. */
    public static final class Request {
        public final String   command;
        public final String[] args;

        Request(String command, String[] args) {
            this.command = command;
            this.args    = args;
        }

        /** Lay tham so thu i, tra ve chuoi rong neu thieu. */
        public String arg(int i) {
            return (i >= 0 && i < args.length) ? args[i] : "";
        }

        public int argCount() { return args.length; }

        @Override public String toString() {
            return command + (args.length == 0 ? "" : " " + Arrays.toString(args));
        }
    }

    /** Mot phan hoi da duoc phan tich. */
    public static final class Response {
        public final int      code;
        public final String   message;
        public final String[] payload;

        Response(int code, String message, String[] payload) {
            this.code    = code;
            this.message = message;
            this.payload = payload;
        }

        public boolean isOk() { return code == OK; }

        /** Lay phan tu payload thu i, tra ve chuoi rong neu thieu. */
        public String data(int i) {
            return (i >= 0 && i < payload.length) ? payload[i] : "";
        }

        @Override public String toString() {
            return code + " " + message + " (" + payload.length + " payload)";
        }
    }

    // ------------------------------------------------------------ dong goi

    /** Tao chuoi yeu cau de gui di. */
    public static String buildRequest(String command, String... args) {
        StringBuilder sb = new StringBuilder(VERSION);
        sb.append('|').append(command);
        for (String a : args) sb.append('|').append(escape(a));
        return sb.toString();
    }

    /** Tao chuoi phan hoi de gui di. */
    public static String buildResponse(int code, String message, String... payload) {
        StringBuilder sb = new StringBuilder(VERSION);
        sb.append('|').append(code);
        sb.append('|').append(escape(message));
        for (String p : payload) sb.append('|').append(escape(p));
        return sb.toString();
    }

    // ------------------------------------------------------------ phan tich

    /** Phan tich chuoi nhan duoc thanh mot Request. */
    public static Request parseRequest(String raw) throws ProtocolException {
        String[] f = splitFields(raw);
        if (f.length < 2) throw new ProtocolException("Goi tin thieu truong");
        if (!VERSION.equals(f[0]))
            throw new ProtocolException("Phien ban khong ho tro: " + f[0]);

        String command = f[1].trim().toUpperCase();
        String[] args  = new String[f.length - 2];
        for (int i = 0; i < args.length; i++) args[i] = unescape(f[i + 2]);

        return new Request(command, args);
    }

    /** Phan tich chuoi nhan duoc thanh mot Response. */
    public static Response parseResponse(String raw) throws ProtocolException {
        String[] f = splitFields(raw);
        if (f.length < 3) throw new ProtocolException("Phan hoi thieu truong");
        if (!VERSION.equals(f[0]))
            throw new ProtocolException("Phien ban khong ho tro: " + f[0]);

        int code;
        try {
            code = Integer.parseInt(f[1].trim());
        } catch (NumberFormatException e) {
            throw new ProtocolException("Ma trang thai khong hop le: " + f[1]);
        }

        String   message = unescape(f[2]);
        String[] payload = new String[f.length - 3];
        for (int i = 0; i < payload.length; i++) payload[i] = unescape(f[i + 3]);

        return new Response(code, message, payload);
    }

    /** Mo ta ngan gon mot ma trang thai, dung khi hien thi loi. */
    public static String codeName(int code) {
        switch (code) {
            case OK:           return "OK";
            case BAD_REQUEST:  return "BAD_REQUEST";
            case UNAUTHORIZED: return "UNAUTHORIZED";
            case NOT_FOUND:    return "NOT_FOUND";
            case CONFLICT:     return "CONFLICT";
            case SERVER_ERROR: return "SERVER_ERROR";
            default:           return "UNKNOWN";
        }
    }

    // ------------------------------------------------------------ kiem tra

    /** Ten account hop le: chu, so, '.', '_', '-' va toi da 32 ky tu. */
    public static boolean isValidAccount(String account) {
        return account != null && account.matches("[A-Za-z0-9._-]{1,32}");
    }

    /** Ten file hop le: khong chua ky tu dieu huong thu muc. */
    public static boolean isValidFileName(String name) {
        return name != null
            && !name.isEmpty()
            && !name.contains("/")
            && !name.contains("\\")
            && !name.contains("..");
    }

    /** Do dai goi tin sau khi ma hoa UTF-8, dung de kiem tra truoc khi gui. */
    public static int byteLength(String message) {
        return message.getBytes(StandardCharsets.UTF_8).length;
    }

    /**
     * Kiem tra nhanh xem goi tin nhan duoc co phai Response (truong 2 la so)
     * hay Request (truong 2 la lenh chu). Dung boi client de phan biet khi nhan
     * goi tin ma khong ro nguon (server push notification).
     */
    public static boolean isLikelyResponse(String raw) {
        if (raw == null) return false;
        String[] f = splitFields(raw);
        if (f.length < 2) return false;
        if (!VERSION.equals(f[0])) return false;
        try { Integer.parseInt(f[1].trim()); return true; }
        catch (NumberFormatException e) { return false; }
    }

    /**
     * Kiem tra do dai va ky tu hop le cua mat khau: 4-32 ky tu.
     */
    public static boolean isValidPassword(String password) {
        return password != null && !password.isEmpty()
            && password.length() >= 4 && password.length() <= 32;
    }

    /**
     * Bam mat khau thanh chuoi hexa (SHA-256). Dung de server khong can luu
     * mat khau goc.
     */
    public static String hashPassword(String password) {
        if (password == null) password = "";
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] bytes = md.digest(password.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder(bytes.length * 2);
            for (byte b : bytes) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            // JDK bat buoc phai co SHA-256, truong hop nay that khoi xay ra
            return Integer.toHexString(password.hashCode());
        }
    }

    // ------------------------------------------------------------ noi bo

    private static String[] splitFields(String raw) {
        // Sau khi escape thi trong cac truong khong con '|' thuc su,
        // nen cat thang bang '|' la an toan.
        List<String> out = new ArrayList<>();
        int start = 0;
        for (int i = 0; i < raw.length(); i++) {
            if (raw.charAt(i) == '|') {
                out.add(raw.substring(start, i));
                start = i + 1;
            }
        }
        out.add(raw.substring(start));
        return out.toArray(new String[0]);
    }

    private static String escape(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length() + 8);
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '\\': sb.append("\\\\"); break;
                case '|':  sb.append("\\p");  break;
                case '\n': sb.append("\\n");  break;
                case '\r': sb.append("\\r");  break;
                default:   sb.append(c);
            }
        }
        return sb.toString();
    }

    private static String unescape(String s) {
        if (s == null) return "";
        StringBuilder sb = new StringBuilder(s.length());
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char n = s.charAt(++i);
                switch (n) {
                    case '\\': sb.append('\\'); break;
                    case 'p':  sb.append('|');  break;
                    case 'n':  sb.append('\n'); break;
                    case 'r':  sb.append('\r'); break;
                    default:   sb.append('\\').append(n);
                }
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
