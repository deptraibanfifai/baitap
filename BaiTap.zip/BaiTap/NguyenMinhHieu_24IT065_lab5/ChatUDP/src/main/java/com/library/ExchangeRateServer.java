package com.library;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.SocketException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

/**
 * ExchangeRateServerGUI: máy chủ tỉ giá có giao diện.
 * - Lắng nghe UDP cổng 2345, mỗi yêu cầu của client là một "phiên".
 * - Tỉ giá thay đổi ngẫu nhiên so với phiên trước (tăng/giảm), hiển thị bằng bảng có màu.
 * - Giao thức trả về giữ nguyên nên ExchangeRateTable (client) dùng được ngay:
 *   dd/MM/yyyy HH:mm:ss;Tokyo=..;NewYork=..;HongKong=..
 */
public class ExchangeRateServer extends JFrame {
    private static final int PORT = 2345;
    private static final int MAX_ROWS = 500;

    // Bảng màu
    private static final Color NAVY   = new Color(0x1F2A44);
    private static final Color BG     = new Color(0xF3F6FB);
    private static final Color UP     = new Color(0x1B9E4B);
    private static final Color DOWN   = new Color(0xD93025);
    private static final Color FLAT   = new Color(0xB8860B);
    private static final Color UP_BG  = new Color(0xE6F6EC);
    private static final Color DOWN_BG = new Color(0xFDEAE8);
    private static final Color FLAT_BG = new Color(0xFFF6DD);

    private static final String[] COLS = {
            "Phiên", "Ngày giờ", "Máy khách",
            "Tokyo (USD/JPY)", "Tăng/giảm",
            "New York (EUR/USD)", "Tăng/giảm",
            "Hồng Kông (USD/HKD)", "Tăng/giảm"
    };
    private static final Color[] HEAD_COLORS = {
            NAVY, NAVY, NAVY,
            new Color(0xE67E22), new Color(0xF0A04B),
            new Color(0x2980B9), new Color(0x5DADE2),
            new Color(0x8E44AD), new Color(0xAF7AC5)
    };

    private final DefaultTableModel model = new DefaultTableModel(COLS, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final JLabel lblStatus = new JLabel();
    private final JLabel lblCount = new JLabel("Số phiên: 0");
    private final JButton btnStart = new JButton("▶  Khởi động");
    private final JButton btnStop = new JButton("■  Dừng");

    private final Random rnd = new Random();
    private final SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");

    private DatagramSocket socket;
    private volatile boolean running = false;
    private int session = 0;
    private double tokyo = 145.00, newYork = 0.9200, hongKong = 7.8000;

    public ExchangeRateServer() {
        super("Exchange Rate Server");
        buildUI();
        setSize(1100, 520);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        startServer();
    }

    // ---------------------------------------------------------------- GIAO DIỆN
    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(0, 10));
        root.setBackground(BG);
        root.setBorder(new EmptyBorder(0, 0, 10, 0));

        // Thanh tiêu đề
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel title = new JLabel("SÀN GIAO DỊCH TỈ GIÁ  –  MÁY CHỦ");
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        JLabel sub = new JLabel("Tokyo  •  New York  •  Hồng Kông   |   UDP cổng " + PORT);
        sub.setFont(new Font("SansSerif", Font.PLAIN, 13));
        sub.setForeground(new Color(0xAFC3E8));
        JPanel titles = new JPanel(new GridLayout(2, 1));
        titles.setOpaque(false);
        titles.add(title);
        titles.add(sub);
        header.add(titles, BorderLayout.WEST);

        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblStatus.setOpaque(true);
        lblStatus.setHorizontalAlignment(SwingConstants.CENTER);
        lblStatus.setBorder(new EmptyBorder(6, 16, 6, 16));
        header.add(lblStatus, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // Bảng
        JTable table = new JTable(model);
        table.setRowHeight(30);
        table.setFont(new Font("SansSerif", Font.PLAIN, 14));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setSelectionBackground(new Color(0xD6E4FF));
        table.setSelectionForeground(Color.BLACK);

        RateRenderer renderer = new RateRenderer();
        for (int i = 0; i < COLS.length; i++) {
            table.getColumnModel().getColumn(i).setCellRenderer(renderer);
        }
        table.getColumnModel().getColumn(0).setPreferredWidth(60);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(130);

        JTableHeader th = table.getTableHeader();
        th.setReorderingAllowed(false);
        th.setPreferredSize(new Dimension(0, 36));
        th.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, s, f, r, c);
                l.setBackground(HEAD_COLORS[c]);
                l.setForeground(Color.WHITE);
                l.setFont(new Font("SansSerif", Font.BOLD, 13));
                l.setHorizontalAlignment(CENTER);
                l.setOpaque(true);
                return l;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(0xD0D7E5)));
        scroll.getViewport().setBackground(Color.WHITE);
        JPanel center = new JPanel(new BorderLayout());
        center.setOpaque(false);
        center.setBorder(new EmptyBorder(0, 14, 0, 14));
        center.add(scroll, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        // Thanh dưới: nút điều khiển + số phiên + chú thích màu
        JPanel bottom = new JPanel(new BorderLayout());
        bottom.setOpaque(false);
        bottom.setBorder(new EmptyBorder(0, 14, 0, 14));

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        buttons.setOpaque(false);
        styleButton(btnStart, UP);
        styleButton(btnStop, DOWN);
        btnStart.addActionListener(e -> startServer());
        btnStop.addActionListener(e -> stopServer());
        JButton btnClear = new JButton("Xóa bảng");
        styleButton(btnClear, new Color(0x607D8B));
        btnClear.addActionListener(e -> { model.setRowCount(0); session = 0; lblCount.setText("Số phiên: 0"); });
        buttons.add(btnStart);
        buttons.add(btnStop);
        buttons.add(btnClear);
        bottom.add(buttons, BorderLayout.WEST);

        JPanel legend = new JPanel(new FlowLayout(FlowLayout.RIGHT, 14, 0));
        legend.setOpaque(false);
        lblCount.setFont(new Font("SansSerif", Font.BOLD, 13));
        legend.add(lblCount);
        legend.add(legendLabel("▲ Tăng", UP));
        legend.add(legendLabel("▼ Giảm", DOWN));
        legend.add(legendLabel("● Không đổi", FLAT));
        bottom.add(legend, BorderLayout.EAST);

        root.add(bottom, BorderLayout.SOUTH);
        setContentPane(root);
    }

    private void styleButton(JButton b, Color bg) {
        b.setBackground(bg);
        b.setForeground(Color.WHITE);
        b.setFont(new Font("SansSerif", Font.BOLD, 13));
        b.setFocusPainted(false);
        b.setOpaque(true);
        b.setBorder(new EmptyBorder(8, 16, 8, 16));
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }

    private JLabel legendLabel(String text, Color c) {
        JLabel l = new JLabel(text);
        l.setForeground(c);
        l.setFont(new Font("SansSerif", Font.BOLD, 13));
        return l;
    }

    private void setStatus(boolean on) {
        lblStatus.setText(on ? "● ĐANG CHẠY" : "● ĐÃ DỪNG");
        lblStatus.setBackground(on ? UP : DOWN);
        lblStatus.setForeground(Color.WHITE);
        btnStart.setEnabled(!on);
        btnStop.setEnabled(on);
    }

    /** Tô màu theo cột "Tăng/giảm" của từng thị trường. */
    private static class RateRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
            l.setHorizontalAlignment(CENTER);
            l.setFont(new Font("SansSerif", c >= 3 ? Font.BOLD : Font.PLAIN, 14));
            l.setForeground(Color.DARK_GRAY);
            l.setBackground(r % 2 == 0 ? Color.WHITE : new Color(0xF8FAFD));

            if (c >= 3) {
                int changeCol = (c % 2 == 0) ? c : c + 1;   // cột 4, 6, 8
                String chg = String.valueOf(t.getValueAt(r, changeCol));
                Color fg, bg;
                if (chg.startsWith("▲"))      { fg = UP;   bg = UP_BG; }
                else if (chg.startsWith("▼")) { fg = DOWN; bg = DOWN_BG; }
                else                           { fg = FLAT; bg = FLAT_BG; }
                if (!sel) {
                    l.setForeground(fg);
                    if (c == changeCol) l.setBackground(bg);
                }
            }
            return l;
        }
    }

    // ------------------------------------------------------------------ SERVER
    private void startServer() {
        if (running) return;
        try {
            socket = new DatagramSocket(PORT);
        } catch (SocketException e) {
            JOptionPane.showMessageDialog(this, "Không mở được cổng " + PORT + ":\n" + e.getMessage(),
                    "Lỗi", JOptionPane.ERROR_MESSAGE);
            setStatus(false);
            return;
        }
        running = true;
        setStatus(true);
        final DatagramSocket s = socket;
        Thread t = new Thread(() -> serve(s), "udp-server");
        t.setDaemon(true);
        t.start();
    }

    private void stopServer() {
        running = false;
        if (socket != null) socket.close();
        setStatus(false);
    }

    private void serve(DatagramSocket s) {
        byte[] buf = new byte[1024];
        while (running) {
            try {
                DatagramPacket req = new DatagramPacket(buf, buf.length);
                s.receive(req);

                // Tỉ giá mới = tỉ giá cũ + biến động ngẫu nhiên (có thể âm hoặc dương)
                double oTokyo = tokyo, oNy = newYork, oHk = hongKong;
                tokyo    = clamp(tokyo    + (rnd.nextDouble() - 0.5) * 1.0,   135, 155);
                newYork  = clamp(newYork  + (rnd.nextDouble() - 0.5) * 0.010, 0.85, 1.00);
                hongKong = clamp(hongKong + (rnd.nextDouble() - 0.5) * 0.020, 7.70, 7.90);

                String time = fmt.format(new Date());
                String msg = String.format(Locale.US, "%s;Tokyo=%.2f;NewYork=%.4f;HongKong=%.4f",
                        time, tokyo, newYork, hongKong);
                byte[] data = msg.getBytes("UTF-8");
                s.send(new DatagramPacket(data, data.length, req.getAddress(), req.getPort()));

                final Object[] row = {
                        ++session, time, req.getAddress().getHostAddress() + ":" + req.getPort(),
                        String.format(Locale.US, "%.2f", tokyo),    change(tokyo - oTokyo, 2),
                        String.format(Locale.US, "%.4f", newYork),  change(newYork - oNy, 4),
                        String.format(Locale.US, "%.4f", hongKong), change(hongKong - oHk, 4)
                };
                SwingUtilities.invokeLater(() -> addRow(row));
            } catch (SocketException e) {
                if (!running) break;          // socket đã bị đóng khi bấm Dừng
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void addRow(Object[] row) {
        model.insertRow(0, row);              // phiên mới nhất nằm trên cùng
        if (model.getRowCount() > MAX_ROWS) model.removeRow(model.getRowCount() - 1);
        lblCount.setText("Số phiên: " + row[0]);
    }

    private static String change(double d, int decimals) {
        String f = "%." + decimals + "f";
        double eps = Math.pow(10, -decimals) / 2;
        if (d > eps)  return "▲ +" + String.format(Locale.US, f, d);
        if (d < -eps) return "▼ " + String.format(Locale.US, f, d);
        return "● " + String.format(Locale.US, f, 0.0);
    }

    private static double clamp(double v, double lo, double hi) {
        return Math.max(lo, Math.min(hi, v));
    }

    public static void main(String[] args) throws Exception {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName()); // để màu nút hiển thị đúng
        SwingUtilities.invokeLater(() -> new ExchangeRateServer().setVisible(true));
    }
}