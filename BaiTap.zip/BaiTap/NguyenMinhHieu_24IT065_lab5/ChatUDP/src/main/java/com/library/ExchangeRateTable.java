package com.library;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.event.MouseInputAdapter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.event.MouseEvent;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketTimeoutException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * ExchangeRateTable: máy khách. Mỗi giây gửi yêu cầu tới server (UDP cổng 2345),
 * cập nhật bảng tỉ giá và vẽ biểu đồ vùng (area chart) cho 3 thị trường.
 * Màu sắc, mũi tên và đường biểu đồ đều đổi theo tăng/giảm của tỉ giá.
 *
 * Cách chạy: java ExchangeRateTable [địa_chỉ_server]   (mặc định localhost)
 */
public class ExchangeRateTable extends JFrame {
    private static final int PORT = 2345;
    private static final int MAX_POINTS = 40;   // số điểm tối đa trên biểu đồ

    private static final Color NAVY    = new Color(0x1F2A44);
    private static final Color BG      = new Color(0xF3F6FB);
    private static final Color BORDER  = new Color(0xD9E0EC);
    private static final Color UP      = new Color(0x1B9E4B);
    private static final Color DOWN    = new Color(0xD93025);
    private static final Color FLAT    = new Color(0xB8860B);
    private static final Color UP_BG   = new Color(0xE6F6EC);
    private static final Color DOWN_BG = new Color(0xFDEAE8);
    private static final Color FLAT_BG = new Color(0xFFF6DD);

    // ------------------------------------------------------------ DỮ LIỆU THỊ TRƯỜNG
    private static class Market {
        final String name, pair;
        final int decimals;
        final Color accent;
        final List<Double> values = new ArrayList<>();
        final List<String> times = new ArrayList<>();
        double change, percent, high = Double.NEGATIVE_INFINITY, low = Double.POSITIVE_INFINITY;

        Market(String name, String pair, int decimals, Color accent) {
            this.name = name; this.pair = pair; this.decimals = decimals; this.accent = accent;
        }

        void add(double v, String time) {
            double prev = values.isEmpty() ? v : values.get(values.size() - 1);
            change = v - prev;
            percent = prev == 0 ? 0 : change / prev * 100;
            high = Math.max(high, v);
            low = Math.min(low, v);
            values.add(v);
            times.add(time);
            if (values.size() > MAX_POINTS) { values.remove(0); times.remove(0); }
        }

        String fmt(double v) { return String.format(Locale.US, "%." + decimals + "f", v); }

        Color moveColor() {
            double eps = Math.pow(10, -decimals) / 2;
            return change > eps ? UP : change < -eps ? DOWN : FLAT;
        }

        String arrow() {
            double eps = Math.pow(10, -decimals) / 2;
            return change > eps ? "▲" : change < -eps ? "▼" : "●";
        }

        String changeText() {
            return arrow() + " " + (change > 0 ? "+" : "") + fmt(change);
        }
    }

    private final Market[] markets = {
            new Market("Tokyo", "USD/JPY", 2, new Color(0xE67E22)),
            new Market("New York", "EUR/USD", 4, new Color(0x2980B9)),
            new Market("Hồng Kông", "USD/HKD", 4, new Color(0x8E44AD))
    };

    private final DefaultTableModel model = new DefaultTableModel(
            new Object[]{"Thị trường", "Tỉ giá", "Tăng/giảm", "% thay đổi", "Cao nhất", "Thấp nhất"}, 0) {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };
    private final ChartPanel[] charts = new ChartPanel[3];
    private final JLabel lblStatus = new JLabel("● ĐANG KẾT NỐI...");
    private final JLabel lblTime = new JLabel("Chưa có dữ liệu");
    private final String host;

    public ExchangeRateTable(String host) {
        super("Bảng tỉ giá thị trường chứng khoán");
        this.host = host;
        buildUI();
        setSize(1180, 640);
        setMinimumSize(new Dimension(900, 520));
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        startUpdater();
    }

    // ------------------------------------------------------------------ GIAO DIỆN
    private void buildUI() {
        JPanel root = new JPanel(new BorderLayout(0, 12));
        root.setBackground(BG);

        // Tiêu đề
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(NAVY);
        header.setBorder(new EmptyBorder(14, 20, 14, 20));
        JLabel title = new JLabel("BẢNG TỈ GIÁ THỊ TRƯỜNG CHỨNG KHOÁN");
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(Color.WHITE);
        lblTime.setFont(new Font("SansSerif", Font.PLAIN, 13));
        lblTime.setForeground(new Color(0xAFC3E8));
        JPanel titles = new JPanel(new GridLayout(2, 1));
        titles.setOpaque(false);
        titles.add(title);
        titles.add(lblTime);
        header.add(titles, BorderLayout.WEST);

        lblStatus.setFont(new Font("SansSerif", Font.BOLD, 13));
        lblStatus.setOpaque(true);
        lblStatus.setBackground(FLAT);
        lblStatus.setForeground(Color.WHITE);
        lblStatus.setBorder(new EmptyBorder(6, 16, 6, 16));
        JPanel statusWrap = new JPanel(new GridBagLayout());
        statusWrap.setOpaque(false);
        statusWrap.add(lblStatus);
        header.add(statusWrap, BorderLayout.EAST);
        root.add(header, BorderLayout.NORTH);

        // Bảng tỉ giá
        for (Market m : markets) model.addRow(new Object[]{m.name + "  (" + m.pair + ")", "-", "-", "-", "-", "-"});
        JTable table = new JTable(model);
        table.setRowHeight(34);
        table.setFont(new Font("SansSerif", Font.PLAIN, 15));
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setFillsViewportHeight(true);
        table.setFocusable(false);
        table.setRowSelectionAllowed(false);
        RateRenderer rr = new RateRenderer();
        for (int i = 0; i < table.getColumnCount(); i++) table.getColumnModel().getColumn(i).setCellRenderer(rr);
        table.getColumnModel().getColumn(0).setPreferredWidth(220);

        JTableHeader th = table.getTableHeader();
        th.setReorderingAllowed(false);
        th.setPreferredSize(new Dimension(0, 36));
        th.setDefaultRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean s, boolean f, int r, int c) {
                JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, s, f, r, c);
                l.setBackground(new Color(0x34495E));
                l.setForeground(Color.WHITE);
                l.setFont(new Font("SansSerif", Font.BOLD, 13));
                l.setHorizontalAlignment(CENTER);
                l.setOpaque(true);
                return l;
            }
        });
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(BORDER));
        scroll.getViewport().setBackground(Color.WHITE);
        scroll.setPreferredSize(new Dimension(0, 36 + 34 * 3 + 4));

        // Biểu đồ
        JPanel chartRow = new JPanel(new GridLayout(1, 3, 14, 0));
        chartRow.setOpaque(false);
        for (int i = 0; i < 3; i++) {
            charts[i] = new ChartPanel(markets[i]);
            chartRow.add(charts[i]);
        }

        JPanel center = new JPanel(new BorderLayout(0, 14));
        center.setOpaque(false);
        center.setBorder(new EmptyBorder(0, 16, 16, 16));
        center.add(scroll, BorderLayout.NORTH);
        center.add(chartRow, BorderLayout.CENTER);
        root.add(center, BorderLayout.CENTER);

        setContentPane(root);
    }

    /** Tô màu bảng theo tăng/giảm của từng dòng. */
    private class RateRenderer extends DefaultTableCellRenderer {
        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foc, int r, int c) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, v, sel, foc, r, c);
            Market m = markets[r];
            l.setHorizontalAlignment(CENTER);
            l.setBackground(r % 2 == 0 ? Color.WHITE : new Color(0xF8FAFD));
            l.setForeground(Color.DARK_GRAY);
            l.setFont(new Font("SansSerif", Font.PLAIN, 15));
            if (c == 0) {
                l.setHorizontalAlignment(LEFT);
                l.setBorder(new EmptyBorder(0, 14, 0, 0));
                l.setForeground(m.accent.darker());
                l.setFont(new Font("SansSerif", Font.BOLD, 15));
            } else {
                l.setBorder(null);
            }
            if (!m.values.isEmpty() && c >= 1 && c <= 3) {
                Color fg = m.moveColor();
                l.setForeground(fg);
                l.setFont(new Font("SansSerif", Font.BOLD, c == 1 ? 17 : 15));
                if (c >= 2) l.setBackground(fg == UP ? UP_BG : fg == DOWN ? DOWN_BG : FLAT_BG);
            }
            return l;
        }
    }

    // ------------------------------------------------------------------ BIỂU ĐỒ
    private static class ChartPanel extends JPanel {
        private final Market m;
        private int hover = -1;

        ChartPanel(Market m) {
            this.m = m;
            setOpaque(false);
            MouseInputAdapter ma = new MouseInputAdapter() {
                @Override public void mouseMoved(MouseEvent e) { hover = indexAt(e.getX()); repaint(); }
                @Override public void mouseExited(MouseEvent e) { hover = -1; repaint(); }
            };
            addMouseMotionListener(ma);
            addMouseListener(ma);
        }

        // Vùng vẽ
        private int left()   { return 58; }
        private int right()  { return getWidth() - 16; }
        private int top()    { return 92; }
        private int bottom() { return getHeight() - 30; }

        private int indexAt(int x) {
            int n = m.values.size();
            if (n == 0 || x < left() - 6 || x > right() + 6) return -1;
            double step = (right() - left()) / (double) (MAX_POINTS - 1);
            int i = (int) Math.round((x - left()) / step);
            return Math.max(0, Math.min(n - 1, i));
        }

        @Override
        protected void paintComponent(Graphics g0) {
            Graphics2D g = (Graphics2D) g0.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
            int W = getWidth(), H = getHeight();

            // Thẻ nền
            g.setColor(Color.WHITE);
            g.fill(new RoundRectangle2D.Double(0, 0, W - 1, H - 1, 18, 18));
            g.setColor(BORDER);
            g.draw(new RoundRectangle2D.Double(0, 0, W - 1, H - 1, 18, 18));
            g.setColor(m.accent);
            g.fill(new RoundRectangle2D.Double(16, 18, 5, 22, 5, 5));

            // Tiêu đề
            g.setFont(new Font("SansSerif", Font.BOLD, 16));
            g.setColor(NAVY);
            g.drawString(m.name, 30, 36);
            int tw = g.getFontMetrics().stringWidth(m.name);
            g.setFont(new Font("SansSerif", Font.PLAIN, 13));
            g.setColor(Color.GRAY);
            g.drawString(m.pair, 30 + tw + 8, 36);

            int n = m.values.size();
            if (n == 0) {
                g.setFont(new Font("SansSerif", Font.ITALIC, 14));
                g.setColor(Color.GRAY);
                String s = "Đang chờ dữ liệu...";
                g.drawString(s, (W - g.getFontMetrics().stringWidth(s)) / 2, H / 2);
                g.dispose();
                return;
            }

            double last = m.values.get(n - 1), first = m.values.get(0);
            Color move = m.moveColor();
            Color trend = n < 2 ? FLAT : (last >= first ? UP : DOWN);

            // Giá hiện tại + mức thay đổi
            g.setFont(new Font("SansSerif", Font.BOLD, 28));
            g.setColor(move);
            g.drawString(m.fmt(last), 18, 74);
            String chg = m.changeText() + "  (" + (m.percent > 0 ? "+" : "") +
                    String.format(Locale.US, "%.2f", m.percent) + "%)";
            g.setFont(new Font("SansSerif", Font.BOLD, 13));
            g.drawString(chg, W - 16 - g.getFontMetrics().stringWidth(chg), 72);

            int L = left(), R = right(), T = top(), B = bottom();
            int pw = R - L, ph = B - T;
            if (pw < 20 || ph < 20) { g.dispose(); return; }

            // Khoảng giá trị
            double min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
            for (double v : m.values) { min = Math.min(min, v); max = Math.max(max, v); }
            double range = max - min;
            if (range < 1e-9) range = Math.max(Math.abs(max) * 0.001, 1e-6);
            double pad = range * 0.18;
            double lo = min - pad, hi = max + pad;

            // Lưới ngang + nhãn trục Y
            g.setFont(new Font("SansSerif", Font.PLAIN, 11));
            for (int i = 0; i <= 4; i++) {
                int y = T + ph * i / 4;
                g.setColor(new Color(0xE9EDF5));
                g.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{4f, 4f}, 0f));
                g.drawLine(L, y, R, y);
                g.setStroke(new BasicStroke(1f));
                g.setColor(Color.GRAY);
                String lab = m.fmt(hi - (hi - lo) * i / 4);
                g.drawString(lab, L - 6 - g.getFontMetrics().stringWidth(lab), y + 4);
            }

            // Tọa độ các điểm
            double step = pw / (double) (MAX_POINTS - 1);
            double[] xs = new double[n], ys = new double[n];
            for (int i = 0; i < n; i++) {
                xs[i] = L + i * step;
                ys[i] = T + (hi - m.values.get(i)) / (hi - lo) * ph;
            }

            // Nhãn thời gian trục X
            g.setColor(Color.GRAY);
            String t0 = m.times.get(0), t1 = m.times.get(n - 1);
            g.drawString(t0, (int) xs[0] - 4, H - 10);
            if (n > 1) g.drawString(t1, Math.min((int) xs[n - 1] - g.getFontMetrics().stringWidth(t1) / 2, W - 16 - g.getFontMetrics().stringWidth(t1)), H - 10);

            // Vùng tô gradient
            if (n >= 2) {
                Path2D area = new Path2D.Double();
                area.moveTo(xs[0], B);
                for (int i = 0; i < n; i++) area.lineTo(xs[i], ys[i]);
                area.lineTo(xs[n - 1], B);
                area.closePath();
                g.setPaint(new GradientPaint(0, T, new Color(trend.getRed(), trend.getGreen(), trend.getBlue(), 95),
                        0, B, new Color(trend.getRed(), trend.getGreen(), trend.getBlue(), 6)));
                g.fill(area);

                // Đường biểu đồ
                Path2D line = new Path2D.Double();
                line.moveTo(xs[0], ys[0]);
                for (int i = 1; i < n; i++) line.lineTo(xs[i], ys[i]);
                g.setStroke(new BasicStroke(2.6f, BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                g.setColor(trend);
                g.draw(line);
            }

            // Các điểm: xanh = tăng so với trước, đỏ = giảm
            double eps = Math.pow(10, -m.decimals) / 2;
            for (int i = 0; i < n; i++) {
                Color c = FLAT;
                if (i > 0) {
                    double d = m.values.get(i) - m.values.get(i - 1);
                    c = d > eps ? UP : d < -eps ? DOWN : FLAT;
                }
                g.setColor(Color.WHITE);
                g.fill(new java.awt.geom.Ellipse2D.Double(xs[i] - 4, ys[i] - 4, 8, 8));
                g.setColor(c);
                g.fill(new java.awt.geom.Ellipse2D.Double(xs[i] - 2.8, ys[i] - 2.8, 5.6, 5.6));
            }

            // Điểm cuối nổi bật + đường ngang giá hiện tại
            double lx = xs[n - 1], ly = ys[n - 1];
            g.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{3f, 3f}, 0f));
            g.setColor(new Color(move.getRed(), move.getGreen(), move.getBlue(), 120));
            g.drawLine(L, (int) ly, R, (int) ly);
            g.setStroke(new BasicStroke(1f));
            g.setColor(new Color(move.getRed(), move.getGreen(), move.getBlue(), 60));
            g.fill(new java.awt.geom.Ellipse2D.Double(lx - 9, ly - 9, 18, 18));
            g.setColor(Color.WHITE);
            g.fill(new java.awt.geom.Ellipse2D.Double(lx - 6, ly - 6, 12, 12));
            g.setColor(move);
            g.fill(new java.awt.geom.Ellipse2D.Double(lx - 4.5, ly - 4.5, 9, 9));

            // Tooltip khi rê chuột
            if (hover >= 0 && hover < n) {
                double hx = xs[hover], hy = ys[hover];
                g.setStroke(new BasicStroke(1f, BasicStroke.CAP_BUTT, BasicStroke.JOIN_MITER, 10f, new float[]{3f, 3f}, 0f));
                g.setColor(new Color(0x7F8FA9));
                g.drawLine((int) hx, T, (int) hx, B);
                g.setStroke(new BasicStroke(1f));
                g.setColor(NAVY);
                g.fill(new java.awt.geom.Ellipse2D.Double(hx - 5, hy - 5, 10, 10));

                String s1 = m.fmt(m.values.get(hover));
                String s2 = m.times.get(hover);
                g.setFont(new Font("SansSerif", Font.BOLD, 13));
                int w1 = g.getFontMetrics().stringWidth(s1);
                g.setFont(new Font("SansSerif", Font.PLAIN, 11));
                int w2 = g.getFontMetrics().stringWidth(s2);
                int bw = Math.max(w1, w2) + 18, bh = 40;
                int bx = (int) Math.max(L, Math.min(hx - bw / 2.0, R - bw));
                int by = (int) Math.max(T - 4, hy - bh - 12);
                g.setColor(NAVY);
                g.fill(new RoundRectangle2D.Double(bx, by, bw, bh, 10, 10));
                g.setColor(Color.WHITE);
                g.setFont(new Font("SansSerif", Font.BOLD, 13));
                g.drawString(s1, bx + (bw - w1) / 2, by + 17);
                g.setColor(new Color(0xAFC3E8));
                g.setFont(new Font("SansSerif", Font.PLAIN, 11));
                g.drawString(s2, bx + (bw - w2) / 2, by + 32);
            }
            g.dispose();
        }
    }

    // ------------------------------------------------------------------ MẠNG
    /** Luồng riêng: mỗi giây gửi yêu cầu, nhận kết quả rồi cập nhật giao diện. */
    private void startUpdater() {
        Thread t = new Thread(() -> {
            try (DatagramSocket socket = new DatagramSocket()) {
                socket.setSoTimeout(900);
                InetAddress addr = InetAddress.getByName(host);
                byte[] req = "GET_RATE".getBytes("UTF-8");
                byte[] buf = new byte[1024];

                while (true) {
                    try {
                        socket.send(new DatagramPacket(req, req.length, addr, PORT));
                        DatagramPacket resp = new DatagramPacket(buf, buf.length);
                        socket.receive(resp);
                        String msg = new String(resp.getData(), 0, resp.getLength(), "UTF-8");
                        SwingUtilities.invokeLater(() -> update(msg));
                    } catch (SocketTimeoutException ex) {
                        SwingUtilities.invokeLater(() -> setStatus(false));
                    }
                    Thread.sleep(1000);
                }
            } catch (InterruptedException ignored) {
            } catch (Exception e) {
                SwingUtilities.invokeLater(() -> { setStatus(false); lblTime.setText("Lỗi: " + e.getMessage()); });
            }
        }, "rate-updater");
        t.setDaemon(true);
        t.start();
    }

    private void setStatus(boolean ok) {
        lblStatus.setText(ok ? "● ĐÃ KẾT NỐI" : "● MẤT KẾT NỐI");
        lblStatus.setBackground(ok ? UP : DOWN);
    }

    /** Phân tích "ngày giờ;Tokyo=..;NewYork=..;HongKong=.." rồi cập nhật bảng + biểu đồ. */
    private void update(String msg) {
        String[] parts = msg.split(";");
        if (parts.length < 4) return;
        String full = parts[0];
        String time = full.contains(" ") ? full.substring(full.indexOf(' ') + 1) : full;
        try {
            for (int i = 0; i < 3; i++) {
                double v = Double.parseDouble(parts[i + 1].substring(parts[i + 1].indexOf('=') + 1));
                Market m = markets[i];
                m.add(v, time);
                model.setValueAt(m.fmt(v), i, 1);
                model.setValueAt(m.changeText(), i, 2);
                model.setValueAt((m.percent > 0 ? "+" : "") + String.format(Locale.US, "%.2f", m.percent) + "%", i, 3);
                model.setValueAt(m.fmt(m.high), i, 4);
                model.setValueAt(m.fmt(m.low), i, 5);
                charts[i].repaint();
            }
            lblTime.setText("Cập nhật lúc: " + full + "   •   Server " + host + ":" + PORT + "   •   làm mới mỗi 1 giây");
            setStatus(true);
        } catch (NumberFormatException ignored) {
        }
    }

    public static void main(String[] args) throws Exception {
        UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
        String host = args.length > 0 ? args[0] : "localhost";
        SwingUtilities.invokeLater(() -> new ExchangeRateTable(host).setVisible(true));
    }
}